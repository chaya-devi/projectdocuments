import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateRegisterComponent } from './create-register/create-register.component';
import { RegisterDetailsComponent } from './register-details/register-details.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { LoginComponent } from './login/login.component';
import { UpdateRegisterComponent } from './update-register/update-register.component';
import { HomeComponent } from './home/home.component';
import { ResponseComponent } from './response/response.component';
import { ReceiverListComponent } from './receiver-list/receiver-list.component';
import { CreateReceiverComponent } from './create-receiver/create-receiver.component';
import { UpdateReceiverComponent } from './update-receiver/update-receiver.component';
import { ReceiverDetailsComponent } from './receiver-details/receiver-details.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'registers', component: RegisterListComponent },
  { path: 'add', component: CreateRegisterComponent },
  { path: 'update/:id', component: UpdateRegisterComponent },
  { path: 'details/:id', component: RegisterDetailsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent },
  { path: 'response', component: ResponseComponent },
  { path: 'receivers', component: ReceiverListComponent },
  { path: 'radd', component: CreateReceiverComponent },
  { path: 'rupdate/:id', component: UpdateReceiverComponent },
  { path: 'rdetails/:id', component: ReceiverDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
