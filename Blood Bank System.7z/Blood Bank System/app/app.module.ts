import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { RegisterListComponent } from './register-list/register-list.component';
import { RegisterService } from './employee.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { CreateRegisterComponent } from './create-register/create-register.component';
import { UpdateRegisterComponent } from './update-register/update-register.component';
import { RegisterDetailsComponent } from './register-details/register-details.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ResponseComponent } from './response/response.component';
import { CreateReceiverComponent } from './create-receiver/create-receiver.component';
import { ReceiverDetailsComponent } from './receiver-details/receiver-details.component';
import { ReceiverListComponent } from './receiver-list/receiver-list.component';
import { UpdateReceiverComponent } from './update-receiver/update-receiver.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterListComponent,
    CreateRegisterComponent,
    UpdateRegisterComponent,
    RegisterDetailsComponent,
    LoginComponent,
    HomeComponent,
    ResponseComponent,
    CreateReceiverComponent,
    ReceiverDetailsComponent,
    ReceiverListComponent,
    UpdateReceiverComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [RegisterService],
  bootstrap: [AppComponent]
})
export class AppModule { }
