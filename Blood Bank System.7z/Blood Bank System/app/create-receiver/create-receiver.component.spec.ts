import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateReceiverComponent } from './create-receiver.component';

describe('CreateReceiverComponent', () => {
  let component: CreateReceiverComponent;
  let fixture: ComponentFixture<CreateReceiverComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateReceiverComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateReceiverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
