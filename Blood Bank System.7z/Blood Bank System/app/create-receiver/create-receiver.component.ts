import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../employee.service';
import { Receiver } from '../receiver';

@Component({
  selector: 'app-create-receiver',
  templateUrl: './create-receiver.component.html',
  styleUrls: ['./create-receiver.component.css']
})
export class CreateReceiverComponent implements OnInit {
  title = 'Registration done';
  receiver: Receiver = new Receiver();
  submitted = false;

  constructor(private registerService: RegisterService, private router: Router) { }

  ngOnInit() {
  }

  newReceiver(): void {
    this.submitted = false;
    this.receiver = new Receiver();
  }

  save() {
    this.registerService.createReceiver(this.receiver).subscribe(data => {
      console.log(data+" "+this.receiver)
     this.receiver = new Receiver();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/response']);
  }


}