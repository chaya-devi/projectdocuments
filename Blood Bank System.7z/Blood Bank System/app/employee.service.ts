import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { User } from './user';
@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  validateRegister(user: Object): Observable<Object> {
    //alert("in service"+user);
    return this.http.post(`${this.baseUrl}/loginUser`, user);
  }
 
  getRegisters(): Observable<any> {
    //console.log(this.http.get(`${this.baseUrl}`+'/getAllEmployees'));
    return this.http.get(`${this.baseUrl}`+'/getAllRegisters');
  }
  getRegister(user_id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getRegister/${user_id}`);
  }

  createRegister(register: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveRegister', register);
  }

  updateRegister(user_id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateRegister/${user_id}`, value);
  }

  deleteRegister(user_id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteRegister/${user_id}`, { responseType: 'text' });
  }






  getReceivers(): Observable<any> {
    //console.log(this.http.get(`${this.baseUrl}`+'/getAllEmployees'));
    return this.http.get(`${this.baseUrl}`+'/getAllReceivers');
  }
  getReceiver(user_id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getReceiver/${user_id}`);
  }

  createReceiver(receiver: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveReceiver', receiver);
  }

  updateReceiver(user_id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateReceiver/${user_id}`, value);
  }

  deleteReceiver(user_id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteReceiver/${user_id}`, { responseType: 'text' });
  }

  isUserLoggedIn() {
    let user = sessionStorage.getItem("username")
    if (user === null) return false
    return true
}
logout() {
  sessionStorage.removeItem("username");
  sessionStorage.setItem("login","failed");
  
}
getLoginStatus()
{
  const loginStatus=sessionStorage.getItem("login");
  return loginStatus;
}
}
