import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RegisterService } from '../employee.service';
import { Receiver } from '../receiver';

@Component({
  selector: 'app-receiver-details',
  templateUrl: './receiver-details.component.html',
  styleUrls: ['./receiver-details.component.css']
})
export class ReceiverDetailsComponent implements OnInit {

  user_id: number=0;
  receiver: Receiver=new  Receiver();

  constructor(private route: ActivatedRoute,private router: Router,private registerService: RegisterService) { }

  ngOnInit() {
    this.receiver = new  Receiver();

    this.user_id = this.route.snapshot.params['user_id'];
    
    this.registerService.getReceiver(this.user_id)
      .subscribe(data => {
        console.log(data)
        this.receiver = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['/receivers']);
  }
}
