import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { RegisterService } from '../employee.service';
import { Receiver } from '../receiver';

@Component({
  selector: 'app-receiver-list',
  templateUrl: './receiver-list.component.html',
  styleUrls: ['./receiver-list.component.css']
})
export class ReceiverListComponent implements OnInit {
  receivers: Observable<Receiver[]>=new Observable;
  username!: string | null;
  loginStatus!: string |null;

  constructor(private registerService: RegisterService,private router: Router) {}
  
  ngOnInit(): void {
    this.getReceivers();
  }

  getReceivers()
  {
    this.loginStatus=this.registerService.getLoginStatus();

   this.username=sessionStorage.getItem("username");
    this.receivers=this.registerService.getReceivers();
  
  }
  
  deleteReceiver(id: number) {
    this.registerService.deleteReceiver(id)
      .subscribe(
        data => {
          console.log(data);
          this.getReceivers();
        },
        error => console.log(error));
  }

  receiverDetails(id: number){
    this.router.navigate(['rdetails', id]);
  }
  updateReceiver(id: number)
  {
    this.router.navigate(['rupdate', id]);
  }
}
