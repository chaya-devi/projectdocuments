export class Receiver {
    user_id:number=0;
    f_name:string="";
    l_name:string="";
    email_id:string="";
    phone_no:number=0;
    reason:string="";
    blood_grp:string="";
    whole_blood:string="";

}