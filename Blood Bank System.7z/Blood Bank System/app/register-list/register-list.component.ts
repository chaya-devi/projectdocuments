import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Register } from '../employee';
import { RegisterService } from '../employee.service';
import { User } from '../user';

@Component({
  selector: 'app-register-list',
  templateUrl: './register-list.component.html',
  styleUrls: ['./register-list.component.css']
})

//component-->service-->http request

export class RegisterListComponent implements OnInit {
  registers: Observable<Register[]>=new Observable;
  username!: string | null;
  loginStatus!: string |null;

  constructor(private registerService: RegisterService,private router: Router) {}
  
  ngOnInit(): void {
    this.getRegisters();
  }

  getRegisters()
  {
    this.loginStatus=this.registerService.getLoginStatus();

   this.username=sessionStorage.getItem("username");
    this.registers=this.registerService.getRegisters();
  
  }
  
  deleteRegister(user_id: number) {
    this.registerService.deleteRegister(user_id)
      .subscribe(
        data => {
          console.log(data);
          this.getRegisters();
        },
        error => console.log(error));
  }

  
  registerDetails(user_id: number){
    this.router.navigate(['details', user_id]);
  }
  updateRegister(user_id: number)
  {
    this.router.navigate(['update',  user_id]);
  }
}
