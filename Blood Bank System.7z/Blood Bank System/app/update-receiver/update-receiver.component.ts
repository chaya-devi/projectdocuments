import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RegisterService } from '../employee.service';
import { Receiver } from '../receiver';

@Component({
  selector: 'app-update-receiver',
  templateUrl: './update-receiver.component.html',
  styleUrls: ['./update-receiver.component.css']
})
export class UpdateReceiverComponent implements OnInit {

  user_id: number=0;
  receiver: Receiver=new Receiver();

  constructor(private route: ActivatedRoute,private router: Router, private registerService: RegisterService) { }

  ngOnInit() {
    this.receiver = new Receiver();

    this.user_id = this.route.snapshot.params['user_id'];
    
    this.registerService.getReceiver(this.user_id)
      .subscribe(data => {
        console.log(data)
        this.receiver = data;
      }, error => console.log(error));
  }

  updateReceiver() {
    this.registerService.updateReceiver(this.user_id, this.receiver)
      .subscribe(data => {
        console.log(data);
        this.receiver = new Receiver();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateReceiver();    
  }

  gotoList() {
    this.router.navigate(['/receivers']);
  }
}