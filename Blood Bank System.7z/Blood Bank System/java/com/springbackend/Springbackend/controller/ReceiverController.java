package com.springbackend.Springbackend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbackend.Springbackend.exception.ResourceNotFoundException;
import com.springbackend.Springbackend.model.Receiver;
import com.springbackend.Springbackend.service.ReceiverService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class ReceiverController {

	@Autowired
	ReceiverService revService;

//http://localhost:8080/api/v1/getAllReceivers
	@GetMapping("/getAllReceivers")
 
	public List<Receiver> getReceiver() {
		List<Receiver> revList = revService.fetchReceiver();

		return revList;

	}

	// http://localhost:8080/api/v1/getReceiver/1
	@GetMapping("/getReceiver/{receiverId}")
	public ResponseEntity<Receiver> getRecieverById(@PathVariable("receiverId") int receiverId)
			throws ResourceNotFoundException {
		Receiver receiver = revService.getReceiver(receiverId);
		return ResponseEntity.ok().body(receiver);
	}

	// http://localhost:8080/api/v1/saveReceiver
	@PostMapping("/saveReceiver")
	public Receiver addReceiver(@RequestBody Receiver rev) {

		Receiver receiver = revService.saveReceiver(rev);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return receiver;
	}

	
	// http://localhost:8080/api/v1/updateReceiver/2
		@PutMapping("/updateReceiver/{id}")
		public ResponseEntity<Receiver> updateReceiver(@PathVariable("id") int receiverId,
				@RequestBody Receiver receiverDetails) throws ResourceNotFoundException {
			Receiver receiver = revService.getReceiver(receiverId);

			receiver.setEmail_id(receiverDetails.getEmail_id());
			receiver.setL_name(receiverDetails.getL_name());
			receiver.setF_name(receiverDetails.getF_name());
			final Receiver updatedReceiver = revService.saveReceiver(receiver);
			return ResponseEntity.ok(updatedReceiver);
		}

	//http://localhost:8080/api/v1/deleteReceiver/1
		@DeleteMapping(value = "/deleteReceiver/{receiverId}")
		public ResponseEntity<String> deleteReceiver(@PathVariable("receiverId") int revId) {

			revService.deleteReceiver(revId);
			return (ResponseEntity<String>) new ResponseEntity<>("Register deleted successsfully", HttpStatus.OK);
		}
		/*
		 * @DeleteMapping("/deleteEmployee/{id}") public Map<String, Boolean>
		 * deleteEmployee(@PathVariable("id") int employeeId) throws
		 * ResourceNotFoundException { // Employee employee =
		 * empService.getEmployee(employeeId);
		 * 
		 * System.out.println("delete method called");
		 * empService.deleteEmployee(employeeId); Map<String, Boolean> response = new
		 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
		 */

	}
