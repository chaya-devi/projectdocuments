package com.springbackend.Springbackend.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="receiver")
public class Receiver {
	@Id
	@GeneratedValue
	@Column(name="user_id")
	private int user_id;
	@Column(name="f_name")
	private String f_name;
	@Column(name="l_name")
	private String l_name;
	@Column(name="email_id")
	private String email_id;
	@Column(name="phone_no")
	private Double phone_no;
	@Column(name="reason")
	private String reason;
	@Column(name="blood_grp")
	private String blood_grp;
	@Column(name="whole_blood")
	private String whole_blood;
	
	
	public Receiver(int user_id,String f_name, String l_name,String email_id,Double phone_no,String reason, String blood_grp, String whole_blood) {
        super();
        this.f_name = f_name;
        this.l_name = l_name;
        this.email_id = email_id;
        this.phone_no = phone_no;
        this.reason=reason;
        this.blood_grp=blood_grp;
        this.whole_blood=whole_blood;
        
        
    }
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	
	
	public String getBlood_grp() {
		return blood_grp;
	}
	public void setBlood_grp(String blood_grp) {
		this.blood_grp = blood_grp;
	}
	
	
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getWhole_blood() {
		return whole_blood;
	}
	public void setWhole_blood(String whole_blood) {
		this.whole_blood = whole_blood;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public Double getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(Double phone_no) {
		this.phone_no = phone_no;
	}
	public Receiver() {
		// TODO Auto-generated constructor stub
	}
	
}