package com.springbackend.Springbackend.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="new_table")
public class Register {
	@Id
	@GeneratedValue
	@Column(name="user_id")
	private int user_id;
	@Column(name="f_name")
	private String f_name;
	@Column(name="l_name")
	private String l_name;
	@Column(name="loc")
	private String loc;
	@Column(name="sex")
	private String sex;
	@Column(name="blood_grp")
	private String blood_grp;
	@Column(name="age")
	private int age;
	@Column(name="weight")
	private int weight;
	@Column(name="email_id")
	private String email_id;
	@Column(name="phone_no")
	private Double phone_no;
	
	public Register(int user_id,String f_name, String l_name,String loc, String sex, String blood_grp,int age,int weight,String email_id,Double phone_no) {
        super();
        this.f_name = f_name;
        this.l_name = l_name;
        this.loc = loc;
        this.sex = sex;
        this.blood_grp=blood_grp;
        this.age=age;
        this.weight=weight;
        this.email_id = email_id;
        this.phone_no = phone_no;
        
    }
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getF_name() {
		return f_name;
	}
	public void setF_name(String f_name) {
		this.f_name = f_name;
	}
	public String getL_name() {
		return l_name;
	}
	public void setL_name(String l_name) {
		this.l_name = l_name;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBlood_grp() {
		return blood_grp;
	}
	public void setBlood_grp(String blood_grp) {
		this.blood_grp = blood_grp;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public Double getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(Double phone_no) {
		this.phone_no = phone_no;
	}
	public Register() {
		// TODO Auto-generated constructor stub
	}
	
}