package com.springbackend.Springbackend.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbackend.Springbackend.dao.ReceiverRepository;
import com.springbackend.Springbackend.model.Receiver;

@Service
public class ReceiverService {

	@Autowired
	ReceiverRepository revRepository;
	
	@Transactional
	public List<Receiver> fetchReceiver() {
		List<Receiver> revList=revRepository.findAll();
		return revList;
		
	}
	@Transactional
	public Receiver saveReceiver(Receiver receiver) {
		
		return revRepository.save(receiver);
		
	}
	@Transactional
	public void updateReceiver(Receiver rev) {
		revRepository.save(rev);	
	
	}
	
	@Transactional
	public void deleteReceiver(int revId) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
		revRepository.deleteById(revId);
	
	}
	@Transactional 
	  public Receiver getReceiver(int user_id) { 
	  Optional<Receiver> optional=revRepository.findById(user_id);
	  Receiver rev=optional.get();
	  return rev;
	  

}
}

