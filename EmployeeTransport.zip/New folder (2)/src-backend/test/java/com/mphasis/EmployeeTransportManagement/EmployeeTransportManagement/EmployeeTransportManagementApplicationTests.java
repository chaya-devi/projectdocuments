package com.mphasis.EmployeeTransportManagement.EmployeeTransportManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeTransportManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
