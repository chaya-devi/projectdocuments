import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { Driver, UsersService } from './driver.service';

@Component({
  selector: 'app-add-edit-driver',
  templateUrl: './add-edit-driver.component.html',
  styleUrls: ['./add-edit-driver.component.css']
})
export class AddEditDriverComponent implements OnInit {
  AddEditDriverForm!:FormGroup;
  observableSubscription!: Subscription;
  editFlag:boolean=false;
  driverId!:number;
  constructor(private formBuilder:FormBuilder,private ngbActiveModal: NgbActiveModal,private usersService:UsersService) { }

  ngOnInit(): void {
    this.createForm();
    if(this.editFlag) this.patchDriverData(this.driverId)
  }
  createForm(){
    this.AddEditDriverForm=this.formBuilder.group({
      DRIVER_ID:["",Validators.compose([Validators.required,Validators.maxLength(4)])],
      DRIVER_NAME:["",Validators.compose([Validators.required,Validators.maxLength(40)])],
      VEHICLE_ID:["",Validators.compose([Validators.required,Validators.maxLength(4)])],
      TIMESLOT_ID:["",Validators.compose([Validators.required,Validators.maxLength(5)])],
    })
  }
  patchDriverData(id:any){
    this.usersService.getDriver(id).subscribe(data=>{
      this.patchData(data);
    },
    error=>{
      console.log(error);
    });
  }

  patchData(data:any){
    this.AddEditDriverForm.controls["DRIVER_ID"].patchValue(data.id );
    this.AddEditDriverForm.controls["DRIVER_NAME"].patchValue(data.driverName);
    this.AddEditDriverForm.controls["VEHICLE_ID"].patchValue(data.vehicleId);
    this.AddEditDriverForm.controls["TIMESLOT_ID"].patchValue(data.timeslotId);
  }

  submit(){
    if(this.editFlag){
      let driver:Driver=new Driver();
      driver.id=this.AddEditDriverForm.controls["DRIVER_ID"].value;
      driver.driverName=this.AddEditDriverForm.controls["DRIVER_NAME"].value;
      driver.vehicleId=this.AddEditDriverForm.controls["VEHICLE_ID"].value;
      driver.timeslotId=this.AddEditDriverForm.controls["TIMESLOT_ID"].value;
      this.usersService.updateDriver(driver).subscribe(data=>{
        this.close();
      },
        error=>{
          console.log(error);
        })
    }
  }
  
  close(){
    this.ngbActiveModal.close();
    }
    ngOnDestroy() {
      if (this.observableSubscription)
        this.observableSubscription.unsubscribe();
    }
}
