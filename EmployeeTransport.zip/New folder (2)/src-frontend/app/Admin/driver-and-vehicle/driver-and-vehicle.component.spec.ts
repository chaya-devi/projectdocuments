import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DriverAndVehicleComponent } from './driver-and-vehicle.component';

describe('DriverAndVehicleComponent', () => {
  let component: DriverAndVehicleComponent;
  let fixture: ComponentFixture<DriverAndVehicleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DriverAndVehicleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DriverAndVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
