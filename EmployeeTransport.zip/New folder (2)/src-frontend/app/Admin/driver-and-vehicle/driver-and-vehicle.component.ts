import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { AddEditDriverComponent } from './add-edit-driver.component';
import { Driver, UsersService } from './driver.service';

@Component({
  selector: 'app-driver-and-vehicle',
  templateUrl: './driver-and-vehicle.component.html',
  styleUrls: ['./driver-and-vehicle.component.css']
})
export class DriverAndVehicleComponent implements OnInit {
  observableSubscription!: Subscription;
  driver:Driver[]=[];
  editFlag:boolean=false;
  constructor(private usersService:UsersService,private modalService: NgbModal) { }

  ngOnInit(): void {
    this.getAllDrivers();
  }

  getAllDrivers(){
    this.observableSubscription=this.usersService.getAllDrivers().subscribe(data=>{
      this.setdata(data);
    },
      error=>{
        console.log(error);
      })
  }

  setdata(data:any){
    this.driver=data;
  }

  deleteDriver(id:any){
    this.observableSubscription=this.usersService.deleteDriver(id).subscribe(data=>{
      let index=this.driver.findIndex(i=>i.id==id);
      if(index>-1) this.driver.splice(index,1);
    },
      error=>{
        console.log(error);
      })
  }

  editDriver(id:any){
    const dialogRef = this.modalService.open(AddEditDriverComponent, { backdrop: 'static' });
    dialogRef.componentInstance.editFlag = true;
    dialogRef.componentInstance.driverId = id;
  }

  ngOnDestroy() {
    if (this.observableSubscription)
      this.observableSubscription.unsubscribe();
  }
}
