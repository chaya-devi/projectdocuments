import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export class Driver{
  public id!:number;
  public driverName!:string;
  public vehicleId!:number;
  public timeslotId!:number;
  
}
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  apiUrl: string;
  constructor(private httpClient: HttpClient) {
    this.apiUrl = "http://localhost:9080/api/v1";
  }

  getAllDrivers(): Observable<Driver> {
    return this.httpClient.get<Driver>(this.apiUrl + "/getAllDrivers");
  }
  deleteDriver(id:number):Observable<any> {
    return this.httpClient.delete<any>(this.apiUrl + "/deleteDriver/"+id);
  }
  getDriver(id:number):Observable<Driver> {
    return this.httpClient.get<Driver>(this.apiUrl + "/getDriver/"+id);
  }
  updateDriver(driver:Driver):Observable<Driver> {
    return this.httpClient.put<Driver>(this.apiUrl + "/updateDriver/"+driver.id,driver);
  }
  
}
