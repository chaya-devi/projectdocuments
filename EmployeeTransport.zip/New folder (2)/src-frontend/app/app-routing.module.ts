import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DriverAndVehicleComponent } from './Admin/driver-and-vehicle/driver-and-vehicle.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found-component/page-not-found-component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home',component: HomeComponent },
  { path: 'dv', component: DriverAndVehicleComponent },
  { path: '**', component: PageNotFoundComponent }
  
];

@NgModule({
  imports: [RouterModule.forRoot(
    routes,{ onSameUrlNavigation: 'reload', useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
