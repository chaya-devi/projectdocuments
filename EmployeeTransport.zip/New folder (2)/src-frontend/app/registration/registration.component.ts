import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormControlDirective, FormGroup, Validators } from '@angular/forms';
import { UrlSerializer } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { Users, UsersService } from './users.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regForm!:FormGroup
  // =new FormGroup({
  //   EmpID:new FormControl(''),
  //   FirstName:new FormControl(''),
  //   LastName:new FormControl(''),
  //   EmailId:new FormControl(''),
  //   UserName:new FormControl(''),
  //   Password:new FormControl(''),
  //   contact:new FormControl('')
  // });
  observableSubscription!: Subscription;
  constructor(private ngbActiveModal: NgbActiveModal,private formBuilder:FormBuilder,private usersService:UsersService) {
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(){
    this.regForm=this.formBuilder.group({
      EmpID:["",Validators.compose([Validators.required,Validators.maxLength(5)])],
      FirstName:["",Validators.compose([Validators.required,Validators.maxLength(40)])],
      LastName:["",Validators.compose([Validators.required,Validators.maxLength(40)])],
      EmailId:["",Validators.compose([Validators.required,Validators.maxLength(30)])],
      UserName:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      Password:["",Validators.compose([Validators.required,Validators.minLength(5), Validators.maxLength(16)])],
      contact:["",Validators.compose([Validators.required,Validators.maxLength(10)])],
    })
  }
submit(){
  let user=new Users();
  user.id=this.regForm.controls["EmpID"].value;
  user.firstName=this.regForm.controls["FirstName"].value;
  user.lastName=this.regForm.controls["LastName"].value;
  user.userName=this.regForm.controls["UserName"].value;
  user.emailId=this.regForm.controls["EmailId"].value;
  user.password=this.regForm.controls["Password"].value;
  user.phoneNumber=this.regForm.controls["contact"].value;
  this.observableSubscription=this.usersService.saveUsers(user).subscribe(data=>{
    console.log("successful");
    this.close();
  },error=>{
    console.log(error);
  });
}
close(){
this.ngbActiveModal.close();
}
ngOnDestroy() {
  if (this.observableSubscription)
    this.observableSubscription.unsubscribe();
}
}
