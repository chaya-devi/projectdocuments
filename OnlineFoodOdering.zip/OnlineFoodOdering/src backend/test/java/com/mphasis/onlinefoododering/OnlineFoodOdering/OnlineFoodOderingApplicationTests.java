package com.mphasis.onlinefoododering.OnlineFoodOdering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodOderingApplicationTests {

	@Test
	void contextLoads() {
	}

}
