import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminreg',
  templateUrl: './adminreg.component.html',
  styleUrls: ['./adminreg.component.css']
})
export class AdminregComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
