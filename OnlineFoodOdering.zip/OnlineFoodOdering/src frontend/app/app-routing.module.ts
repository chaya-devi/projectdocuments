import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundError } from 'rxjs';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminregComponent } from './adminreg/adminreg.component';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { CreateCartComponent } from './create-cart/create-cart.component';
import { CartDetailsComponent } from './cart-details/cart-details.component';
import { CartListComponent } from './cart-list/cart-list.component';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { CreateVieworderComponent } from './create-vieworder/create-vieworder.component';
import { VieworderDetailsComponent } from './vieworder-details/vieworder-details.component';
import { VieworderListComponent } from './vieworder-list/vieworder-list.component';
import { UpdateVieworderComponent } from './update-vieworder/update-vieworder.component';
import { TranscationDetailsComponent } from './transcation-details/transcation-details.component';
import { TranscationListComponent } from './transcation-list/transcation-list.component';
import { UpdateTranscationComponent } from './update-transcation/update-transcation.component';

const routes: Routes = [{path: 'adminpage', component: AdminpageComponent},{path: 'adminreg', component: AdminregComponent},
{path: 'home', component: HomeComponent},{path: 'menu', component: MenuComponent},  { path: 'cart', component: CartListComponent },

  { path: '', redirectTo: 'cart', pathMatch: 'full' },

  { path: 'add', component: CreateCartComponent },
  { path: 'update/:id', component: UpdateCartComponent },
  { path: 'details/:id', component: CartDetailsComponent },
  { path: '', redirectTo: 'vieworder', pathMatch: 'full' },
  { path: 'vieworder', component: VieworderListComponent },
  { path: 'add', component: CreateVieworderComponent },
  { path: 'update/:id', component: UpdateVieworderComponent },
  { path: 'details/:id', component: VieworderDetailsComponent },
  { path: '', redirectTo: 'transaction', pathMatch: 'full' },
  { path: 'transtatus', component: TranscationListComponent},
  
  { path: 'update/:transid', component: UpdateTranscationComponent}
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
