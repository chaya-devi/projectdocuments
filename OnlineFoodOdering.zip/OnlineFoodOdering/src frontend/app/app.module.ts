import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AdminregComponent } from './adminreg/adminreg.component';
import { HomeComponent } from './home/home.component';
import { MenuComponent } from './menu/menu.component';
import { UserordersComponent } from './userorders/userorders.component';
import { UsercartComponent } from './usercart/usercart.component';
import { CartService } from './cart.service';
import { VieworderService } from './vieworder.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CreateCartComponent } from './create-cart/create-cart.component';
import { CartDetailsComponent } from './cart-details/cart-details.component';
import { CartListComponent } from './cart-list/cart-list.component';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { CreateVieworderComponent } from './create-vieworder/create-vieworder.component';
import { VieworderDetailsComponent } from './vieworder-details/vieworder-details.component';
import { VieworderListComponent } from './vieworder-list/vieworder-list.component';
import { UpdateVieworderComponent } from './update-vieworder/update-vieworder.component';
import { TranscationDetailsComponent } from './transcation-details/transcation-details.component';
import { TranscationListComponent } from './transcation-list/transcation-list.component';
import { UpdateTranscationComponent } from './update-transcation/update-transcation.component';
import { MenuHomeComponent } from './menu-home/menu-home.component';

@NgModule({
  declarations: [
    AppComponent,
    AdminpageComponent,
    AdminregComponent,
    HomeComponent,
    MenuComponent,
    UserordersComponent,
    UsercartComponent,
    CreateCartComponent,
    CartDetailsComponent,
    CartListComponent,
    UpdateCartComponent,
    CreateVieworderComponent,
    VieworderDetailsComponent,
    VieworderListComponent,
    UpdateVieworderComponent,
    TranscationDetailsComponent,
    TranscationListComponent,
    UpdateTranscationComponent,
    TranscationDetailsComponent,
    TranscationListComponent,
    UpdateTranscationComponent,
    MenuHomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
