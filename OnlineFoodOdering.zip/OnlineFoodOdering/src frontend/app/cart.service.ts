import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class CartService {
  private baseUrl = 'http://localhost:9080/api/v1';

  constructor(private http: HttpClient) { }
  getCart(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllCart');
  }
  getCar(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getCart/${id}`);
  }

  createCart(cart: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveCart', cart);
  }

  updateCart(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateCart/${id}`, value);
  }

  deleteCart(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteCart/${id}`, { responseType: 'text' });
  }

}
