export class Cart{
    
    Userid:number=0;
    quantity:number=1;
    itemId:number=0;
    
}