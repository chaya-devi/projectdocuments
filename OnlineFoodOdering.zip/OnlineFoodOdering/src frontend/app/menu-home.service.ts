import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MenuHomeService {
  private baseUrl = 'http://localhost:9080/api/v1';

  constructor(private http: HttpClient) { }
  getMenu(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllMenu');
  }
  getMenuHome(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getMenu/${id}`);
  }

  createMenuHome(MenuHome: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveMenu', MenuHome);
  }

  updateMenuHome(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateMenu/${id}`, value);
  }

  deleteMenuHome(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteMenu/${id}`, { responseType: 'text' });
  }

}
