import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MenuHome } from '../menuhome'
import { MenuHomeService } from '../menu-home.service';

@Component({
  selector: 'app-menu-home', 
  templateUrl: './menu-home.component.html',
  styleUrls: ['./menu-home.component.css']
})
export class MenuHomeComponent implements OnInit {
  MenuHome: Observable<MenuHome[]>=new Observable;

  constructor(private MenuHomeService: MenuHomeService,private router: Router) { }

  ngOnInit(): void {
    this.getMenuHome();
  }

  getMenuHome()
  {
    this.MenuHome=this.MenuHomeService.getMenu();
  }
  
  deleteMenuHome(id: number) {
    this.MenuHomeService.deleteMenuHome(id).subscribe(
        data => {
          console.log(data);
          this.getMenuHome();
        },
        error => console.log(error));
  }

  updatemenuHome(id: number)
  {
    this.router.navigate(['update', id]);
  }

}
