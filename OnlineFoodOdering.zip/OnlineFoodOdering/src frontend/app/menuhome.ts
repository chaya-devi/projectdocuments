export class MenuHome{
    
    Userid:number=0;
    quantity:number=1;
    itemId:number=0;
    
}