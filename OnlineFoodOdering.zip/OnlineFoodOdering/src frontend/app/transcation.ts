export class TransactionStatus{
    transid:number=0;
    userid:number=20;
    orderid: number=20;
    transdate: string="";
    price: number=10;
    stat: string="";
}