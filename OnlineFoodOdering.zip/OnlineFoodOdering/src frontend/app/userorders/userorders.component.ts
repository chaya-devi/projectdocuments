import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userorders',
  templateUrl: './userorders.component.html',
  styleUrls: ['./userorders.component.css']
})
export class UserordersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
