import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class VieworderService {

  private baseUrl = 'http://localhost:9080/api/v1';
  constructor(private http: HttpClient) { }
  getVieworders(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllOrders');
  }
  getVieworder(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getOrder/${id}`);
  }

  createVieworders(order: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveOrder', order)
  }

  updateVieworders(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateOrder/${id}`, value);
  }

  deleteVieworders(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteOrder/${id}`, { responseType: 'text' });
  }

}
