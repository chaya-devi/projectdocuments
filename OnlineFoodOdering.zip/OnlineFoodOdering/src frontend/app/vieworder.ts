export class Vieworder{
    item_id: number=1;
    item_name:number=1;
    item_description:number=1;
    price:number=0;
    active:number=1;
    category:number=5;
    date_of_launch:number=2;
    free_delivery:number=0;

    
}
