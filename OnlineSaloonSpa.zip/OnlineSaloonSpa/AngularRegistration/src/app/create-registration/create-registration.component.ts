import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Registration } from '../registration';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-create-registration',
  templateUrl: './create-registration.component.html',
  styleUrls: ['./create-registration.component.css']
})
export class CreateRegistrationComponent implements OnInit {

  registration: Registration = new Registration();
  submitted = false;

  constructor(private registrationService: RegistrationService, private router: Router) { }

  ngOnInit() {
  }

  newRegistration(): void {
    this.submitted = false;
    this.registration = new Registration();
  }

  save() {
    this.registrationService.createRegistration(this.registration).subscribe(data => {
      console.log(data+" "+this.registration)
     this.registration = new Registration();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/add']);
  }

}
