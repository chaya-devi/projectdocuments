import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  private baseUrl = 'http://localhost:8088/api/v1';

  constructor(private http: HttpClient) { }

  createRegistration(registration: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveRegistration', registration);
  }

}
