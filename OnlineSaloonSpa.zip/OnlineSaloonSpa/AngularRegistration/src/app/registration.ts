export class Registration{
    id:number=0;
    firstName:string="";
    lastName:string="";
    emailId:string="";
    password:string="";
    phonenum:number=0;
    gender:string="";


}