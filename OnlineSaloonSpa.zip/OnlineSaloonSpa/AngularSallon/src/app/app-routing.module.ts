import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateServicesComponent } from './create-services/create-services.component';
import { ServicesDetailsComponent } from './services-details/services-details.component';
import { ServicesListComponent } from './services-list/services-list.component';
import { UpdateServicesComponent } from './update-services/update-services.component';

const routes: Routes = [
  { path: '', redirectTo: 'services', pathMatch: 'full' },
  { path: 'employees', component: ServicesListComponent },
  { path: 'add', component: CreateServicesComponent },
  { path: 'update/:id', component: UpdateServicesComponent },
  { path: 'details/:id', component: ServicesDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
