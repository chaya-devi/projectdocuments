import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { ServicesService } from './services.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { CreateServicesComponent } from './create-services/create-services.component';
import { ServicesDetailsComponent } from './services-details/services-details.component';
import { ServicesListComponent } from './services-list/services-list.component';
import { UpdateServicesComponent } from './update-services/update-services.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateServicesComponent,
    ServicesDetailsComponent,
    ServicesListComponent,
    UpdateServicesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
