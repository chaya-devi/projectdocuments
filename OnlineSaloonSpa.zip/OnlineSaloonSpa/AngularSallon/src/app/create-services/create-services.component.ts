import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Services } from '../services';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-create-services',
  templateUrl: './create-services.component.html',
  styleUrls: ['./create-services.component.css']
})
export class CreateServicesComponent implements OnInit {

  services: Services = new Services();
  submitted = false;

  constructor(private servicesService: ServicesService, private router: Router) { }

  ngOnInit()  {
  }

  newServices(): void {
    this.submitted = false;
    this.services = new Services();
  }

  save() {
    this.servicesService.createServices(this.services).subscribe(data => {
      console.log(data+" "+this.services)
     this.services = new Services();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/employees']);
  }

}
