import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Services } from '../services';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-services-details',
  templateUrl: './services-details.component.html',
  styleUrls: ['./services-details.component.css']
})
export class ServicesDetailsComponent implements OnInit {

  id: number=0;
  services: Services=new Services();

  constructor(private route: ActivatedRoute,private router: Router,private servicesService: ServicesService) { }

  ngOnInit() {
    this.services = new Services();

    this.id = this.route.snapshot.params['id'];
    
    this.servicesService.getService(this.id)
      .subscribe(data => {
        console.log(data)
        this.services = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['services']);
  }

}
