import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Services } from '../services';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-services-list',
  templateUrl: './services-list.component.html',
  styleUrls: ['./services-list.component.css']
})
export class ServicesListComponent implements OnInit {
  services: Observable<Services[]>=new Observable;

  constructor(private serviceService: ServicesService,private router: Router) { }

  ngOnInit(): void {
    this.getServices();
  }
  getServices() {
    throw new Error('Method not implemented.');
  }

  getEmployees()
  {
    this.services=this.serviceService.getServices();
  }
  
  deleteServices(id: number) {
    this.serviceService.deleteServices(id)
      .subscribe(
        data => {
          console.log(data);
          this.getServices();
        },
        error => console.log(error));
  }

  servicesDetails(id: number){
    this.router.navigate(['details', id]);
  }
  updateServices(id: number)
  {
    this.router.navigate(['update', id]);
  }

}
