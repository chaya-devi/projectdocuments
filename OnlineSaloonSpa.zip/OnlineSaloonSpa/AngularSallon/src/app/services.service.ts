import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  private baseUrl = 'http://localhost:8088/api/v1';

  constructor(private http: HttpClient) { }

  getServices(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllServices');
  }
  getService(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getServices/${id}`);
  }

  createServices(services: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveServices',services);
  }

  updateServices(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateServices/${id}`, value);
  }

  deleteServices(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteServices/${id}`, { responseType: 'text' });
  }
}
