export class Services{
    id:number=0;
    serviceName:string="";
    cost:number=0;
    status:string="";
}