import { Component, OnInit } from '@angular/core';
import { Services } from '../services';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesService } from '../services.service';

@Component({
  selector: 'app-update-services',
  templateUrl: './update-services.component.html',
  styleUrls: ['./update-services.component.css']
})
export class UpdateServicesComponent implements OnInit {

  id: number=0;
  services: Services=new Services();

  constructor(private route: ActivatedRoute,private router: Router,
    private servicesService: ServicesService) { }

  ngOnInit(): void {
    this.services = new Services();

    this.id = this.route.snapshot.params['id'];
    
    this.servicesService.getServices()
      .subscribe(data => {
        console.log(data)
        this.services = data;
      }, error => console.log(error));
  }

  updateEmployee() {
    this.servicesService.updateServices(this.id, this.services)
      .subscribe(data => {
        console.log(data);
        this.services = new Services();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateEmployee();    
  }

  gotoList() {
    this.router.navigate(['/services']);
  }
  

}
