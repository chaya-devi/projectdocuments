package com.mphasis.saloonspa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.saloonspa.exception.ResourceNotFoundException;
import com.mphasis.saloonspa.model.Admin;
import com.mphasis.saloonspa.service.AdminService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class AdminController {

	@Autowired
	AdminService admService;

//http://localhost:8088/api/v1/getAllAdmin
	@GetMapping("/getAllAdmin")
	public List<Admin> getAdmin() {
		List<Admin> admList = admService.fetchAdmine();

		return admList;

	}

	// http://localhost:8088/api/v1/getAdmin/1
	@GetMapping("/getAdmin/{adminserviceid}")
	public ResponseEntity<Admin> getAdminByserviceid(@PathVariable("adminserviceid") int adminserviceid)
			throws ResourceNotFoundException {
		Admin admin = admService.getAdmin(adminserviceid);
		return ResponseEntity.ok().body(admin);
	}

	// http://localhost:8088/api/v1/saveAdmin
	@PostMapping("/saveAdmin")
	public Admin addAdmin(@RequestBody Admin adm) {

		Admin admin = admService.saveAdmin(adm);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return admin;
	}

	// http://localhost:8088/api/v1/updateAdmin/2
	@PutMapping("/updateAdmin/{serviceid}")
	public ResponseEntity<Admin> updateAdmin(@PathVariable("serviceid") int adminserviceid,
			@RequestBody Admin adminDetails) throws ResourceNotFoundException {
		Admin admin = admService.getAdmin(adminserviceid);

		admin.setserviceName(adminDetails.getserviceName());
		admin.setservicecost(adminDetails.getservicecost());
		
	
		final Admin updatedAdmin = admService.saveAdmin(admin);
		return ResponseEntity.ok(updatedAdmin);
	}

//http://localhost:8088/api/v1/deleteAdmin/1
	@DeleteMapping(value = "/deleteAdmin/{adminPgid}")
	public ResponseEntity<Object> deleteAdmin(@PathVariable("adminserviceid") int admserviceid) {

		admService.deleteAdmin(admserviceid);
		return new ResponseEntity<>("Admin deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deleteEmployee/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int employeeId) throws
	 * ResourceNotFoundException { // Employee employee =
	 * empService.getEmployee(employeeId);
	 * 
	 * System.out.println("delete method called");
	 * empService.deleteEmployee(employeeId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}
