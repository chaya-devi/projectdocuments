package com.mphasis.saloonspa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.saloonspa.exception.ResourceNotFoundException;

import com.mphasis.saloonspa.model.Booking;

import com.mphasis.saloonspa.service.BookingService;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class BookingController {

	@Autowired
	BookingService bkService;

//http://localhost:8088/api/v1/getAllBooking
	@GetMapping("/getAllBooking")
	public List<Booking> getBooking() {
		List<Booking> bkList = bkService.fetchBoooking();

		return bkList;

	}

	// http://localhost:8088/api/v1/getBooking/1
	@GetMapping("/getBooking/{bookinguserid}")
	public ResponseEntity<Booking> getBookingByuserid(@PathVariable("bookinguserid") int bookinguserid)
			throws ResourceNotFoundException {
		Booking booking = bkService.getBooking(bookinguserid);
		return ResponseEntity.ok().body(booking);
	}

	// http://localhost:8088/api/v1/saveBooking
	@PostMapping("/saveBooking")
	public Booking addBooking(@RequestBody Booking bk) {

		Booking booking = bkService.saveBooking(bk);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return booking;
	}

	// http://localhost:8088/api/v1/updateBooking/2
	@PutMapping("/updateBooking/{userid}")
	public ResponseEntity<Booking> updateBooking(@PathVariable("userid") int bookinguserid,
			@RequestBody Booking bookingDetails) throws ResourceNotFoundException {
		Booking booking = bkService.getBooking(bookinguserid);
		
		booking.setuserid(bookingDetails.getuserid());
		booking.setserviceid(bookingDetails.getserviceid());
		booking.setbookingnumber(bookingDetails.getbookingnumber());
		booking.setappointmentdate(bookingDetails.getappointmentdate());
		//booking.setappointmenttime(bookingDetails.getappointmenttime());
		booking.setaction(bookingDetails.getaction());
	
		final Booking updatedBooking = bkService.saveBooking(booking);
		return ResponseEntity.ok(updatedBooking);
	}

//http://localhost:8080/api/v1/deleteBooking/1
	@DeleteMapping(value = "/deleteBooking/{bookinguserid}")
	public ResponseEntity<Object> deleteBooking(@PathVariable("bookinguserid") int bkuserid) {

		bkService.deleteBooking(bkuserid);
		return new ResponseEntity<>("Booking deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deleteEmployee/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int employeeId) throws
	 * ResourceNotFoundException { // Employee employee =
	 * empService.getEmployee(employeeId);
	 * 
	 * System.out.println("delete method called");
	 * empService.deleteEmployee(employeeId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}
