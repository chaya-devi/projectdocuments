package com.mphasis.saloonspa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.saloonspa.exception.ResourceNotFoundException;
import com.mphasis.saloonspa.model.Services;
import com.mphasis.saloonspa.service.ServicesService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class ServicesController {

	@Autowired
	ServicesService servicesService;

//http://localhost:8088/api/v1/getAllServices
	@GetMapping("/getAllServices")
	public List<Services> getServices() {
		List<Services> servicesList = servicesService.fetchServices();

		return servicesList;

	}

	// http://localhost:8088/api/v1/getServices/1
	@GetMapping("/getServices/{serviceId}")
	public ResponseEntity<Services> getServicesById(@PathVariable("serviceId") int serviceId)
			throws ResourceNotFoundException {
		Services services = servicesService.getServices(serviceId);
		return ResponseEntity.ok().body(services);
	}

	// http://localhost:8088/api/v1/saveServices
	@PostMapping("/saveServices")
	public Services addServices(@RequestBody Services services) {
		services  = servicesService.saveServices(services);

		// return new ResponseEntity<>("PayingGuest added successsfully", HttpStatus.OK);
		return services;
	}

	// http://localhost:8088/api/v1/updateServices/3
	@PutMapping("/updateServices/{id}")
	public ResponseEntity<Services> updateServices(@PathVariable("id") int serviceId,
			@RequestBody Services servicesDetails) throws ResourceNotFoundException {
		Services services = servicesService.getServices(serviceId);

		services.setServiceName(servicesDetails.getServiceName());
		services.setCost(servicesDetails.getCost());
		services.setStatus(servicesDetails.getStatus());
		
		final Services updatedServices = servicesService.saveServices(services);
		return ResponseEntity.ok(updatedServices);
	}

//http://localhost:8080/api/v1/Services/1
	@DeleteMapping(value = "/deleteServices/{serviceId}")
	public ResponseEntity<Object> deleteServices(@PathVariable("serviceId") int serviceId) {

		servicesService.deleteServices(serviceId);
		return new ResponseEntity<>("PayingGuest deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deletePayingGuest/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int pgId) throws
	 * ResourceNotFoundException { // PayingGuest payingguest =
	 * pgService.getPayingGuest(pgId);
	 * 
	 * System.out.println("delete method called");
	 * pgService.deletePayingGuest(pgId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}


