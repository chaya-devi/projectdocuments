package com.mphasis.saloonspa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.saloonspa.exception.ResourceNotFoundException;
import com.mphasis.saloonspa.model.User;
import com.mphasis.saloonspa.service.UserService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class UserController {

	@Autowired
	UserService userService;

//http://localhost:8088/api/v1/getAllUsers
	@GetMapping("/getAllUsers")
	public List<User> getUsers() {
		List<User> userList = userService.fetchUser();

		return userList;

	}

	// http://localhost:8088/api/v1/getUser/101
	@GetMapping("/getUser/{userid}")
	public ResponseEntity<User> getUserById(@PathVariable("userid") int userid)
			throws ResourceNotFoundException {
		User user = userService.getUser(userid);
		return ResponseEntity.ok().body(user);
	}

	// http://localhost:8088/api/v1/saveUser
	@PostMapping("/saveUser")
	public User addUser(@RequestBody User user) {

		//User user = userService.saveUser(user);

		//return new ResponseEntity<>("User added successsfully", HttpStatus.OK);
		return user;
	}

	// http://localhost:8088/api/v1/updateUser/102
	@PutMapping("/updateUser/{userid}")
	public ResponseEntity<User> updateUser(@PathVariable("userid") int userid,
			@RequestBody User userDetails) throws ResourceNotFoundException {
		User user = userService.getUser(userid);

		user.setemail(userDetails.getemail());
		user.setusername(userDetails.getusername());
		user.setphonenumber(userDetails.getphonenumber());
		final User updatedUser = userService.saveUser(user);
		return ResponseEntity.ok(updatedUser);
	}

//http://localhost:8088/api/v1/deleteUser/103
	@DeleteMapping(value = "/deleteUser/{userid}")
	public ResponseEntity<Object> deleteUser(@PathVariable("userid") int userid) {

		userService.deleteUser(userid);
		return new ResponseEntity<>("User deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deleteUser/{userid}") public Map<String, Boolean>
	 * deleteUser(@PathVariable("userid") int userid) throws
	 * ResourceNotFoundException { // User user =
	 * userService.getUser(userid);
	 * 
	 * System.out.println("delete method called");
	 * empService.deleteUser(userid); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}


