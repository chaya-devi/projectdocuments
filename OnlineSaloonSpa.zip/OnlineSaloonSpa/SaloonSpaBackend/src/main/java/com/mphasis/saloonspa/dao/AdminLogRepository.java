package com.mphasis.saloonspa.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mphasis.saloonspa.model.AdminRegistration;
import com.mphasis.saloonspa.model.AdminLogin;

public interface AdminLogRepository extends JpaRepository<AdminRegistration, String>{
	@Query("SELECT al FROM AdminLogin al WHERE al.adminid =?1 and al.password=?2")
			public AdminLogin validateAdminLogin(int adminid,String password);

	
	
	
}
