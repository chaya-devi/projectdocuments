package com.mphasis.saloonspa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {
	@Id
	@GeneratedValue
	@Column(name="serviceid")
	private int serviceid;
	@Column(name="servicename")
	
	private String serviceName;
	@Column(name="servicecost")
	private int servicecost;
	
	
	public Admin(String servicename, int servicecost) {
        super();
        this.serviceName = servicename;
        this.servicecost = servicecost;
        
    }
	public Admin() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getserviceid() {
		return serviceid;
	}
	public void setserviceid(int serviceid) {
		this.serviceid = serviceid;
	}
	public String getserviceName() {
		return serviceName;
	}
	public void setserviceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public int getservicecost() {
		return servicecost;
	}
	public void setservicecost(int servicecost) {
		this.servicecost = servicecost;
	}
	
	

}
