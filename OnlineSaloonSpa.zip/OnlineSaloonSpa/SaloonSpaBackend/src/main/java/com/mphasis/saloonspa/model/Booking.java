package com.mphasis.saloonspa.model;



import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="booking")
public class Booking {

	@Id
	@Column(name="userid")
	
	private int userid;
	@Column(name="serviceid")
	private int serviceid;
	@Column(name="bookingnumber")
	private int bookingnumber;
	@Column(name="appointmentdate")
	@Temporal(TemporalType. DATE) 
	private Date appointmentdate;
	//@Column(name="moveout")
	//@Temporal(TemporalType. DATE) 
	//private Date moveout;
	//@Column(name="appointmenttime")
	//@Temporal(TemporalType. TIME) 
	//private Time appointmenttime;
	@Column(name="action")
	private String action;
	public Booking(int userid, int serviceid, int bookingnumber, Date appointmentdate, String action) {
        super();
        
        this.userid = userid;
        this.serviceid = serviceid;
        this.bookingnumber =bookingnumber;
        this.appointmentdate=appointmentdate;
        //this.appointmenttime=appointmenttime;
        this.action=action;
    }
	public Booking() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public int getuserid() {
		return userid;
	}
	public void setuserid(int userid) {
		this.userid = userid;
	}
	public int getserviceid() {
		return serviceid;
	}
	public void setserviceid(int serviceid) {
		this.serviceid = serviceid;
	}
	public int getbookingnumber() {
		return bookingnumber;
	}
	public void setbookingnumber(int bookingnumber) {
		this.bookingnumber = bookingnumber;
	}
	public Date getappointmentdate() {
		return appointmentdate;
	}
	public void setappointmentdate(Date appointmentdate) {
		this.appointmentdate = appointmentdate;
		
	}
	/*public Time getappointmenttime() {
		return appointmenttime;
	}
	public void setappointmenttime(Time appointmenttime) {
		this.appointmenttime=appointmenttime;
	}*/
	public String getaction() {
		return action;
	}
	public void setaction(String action) {
		this.action=action;
	}
	

}

