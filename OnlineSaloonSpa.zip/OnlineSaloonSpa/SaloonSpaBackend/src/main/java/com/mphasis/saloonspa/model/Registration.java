package com.mphasis.saloonspa.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="registration_info")
public class Registration {
	@Id
	@GeneratedValue
	@Column(name="userid")
	private int id;
	@Column(name="firstname")
	private String firstName;
	@Column(name="lastname")
	private String lastName;
	@Column(name="email")
	private String emailId;
	@Column(name="password")
	private String password;
	@Column(name = "phonenum", nullable = false, length = 60)
	private int phonenum;
	@Column(name="gender")
	private String gender;
	
	public Registration(String firstName, String lastName, String emailId, String password, int phonenum, String gender) {
		
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.emailId = emailId;
        this.password=password;
        this.phonenum = phonenum;
        this.gender= gender;
    }
	public Registration() {
		// TODO Auto-generated constructor stub
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getpassword() {
		return password;
	}
	public void setpassword(String password) {
		this.password = password;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getphonenum() {
		return phonenum;
	}
	public void setphonenum(int phonenum) {
		this.phonenum = phonenum;
	}
	public String getgender() {
		return gender;
	}
	public void setgenderId(String gender) {
		this.gender = gender;
	}
	
	

}