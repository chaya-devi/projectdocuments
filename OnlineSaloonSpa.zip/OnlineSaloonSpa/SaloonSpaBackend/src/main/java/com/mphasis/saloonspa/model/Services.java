package com.mphasis.saloonspa.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Services")
public class Services {
	@Id
	@GeneratedValue
	@Column(name="serviceid")
	private int id;
	@Column(name="servicename")
	
	private String serviceName;
	@Column(name="cost")
	private int cost;
	
	@Column(name="status")
	private String status;
	
	public Services(String serviceName, int cost, String status) {
        super();
        this.serviceName=serviceName;
        this.cost= cost;
        this.status= status;
    }
	public Services() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	

	
	
	



	

}