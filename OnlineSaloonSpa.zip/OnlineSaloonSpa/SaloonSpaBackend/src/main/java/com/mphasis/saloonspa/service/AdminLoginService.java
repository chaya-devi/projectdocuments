package com.mphasis.saloonspa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.AdminLogRepository;
import com.mphasis.saloonspa.model.AdminLogin;

@Service
public class AdminLoginService {

	@Autowired
	AdminLogRepository adminlogRepository;

	public AdminLogin validateAdminLogin(AdminLogin adminlogin) {
		AdminLogin al=adminlogRepository.validateAdminLogin(adminlogin.getAdminid(),adminlogin.getPassword());
		
		return al;
	}
	
}