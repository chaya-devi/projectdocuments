package com.mphasis.saloonspa.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.AdminRegRepository;
import com.mphasis.saloonspa.model.AdminRegistration;;


@Service
public class AdminRegService {

	@Autowired
	AdminRegRepository adminRegRepository;
	
	@Transactional
	public List<AdminRegistration> fetchAdminRegistration() {
		List<AdminRegistration> adminRegistrationList=adminRegRepository.findAll();
		return adminRegistrationList;
		
	}
//@Transactional
	public AdminRegistration saveAdminRegistration (AdminRegistration adminRegistration) {
		
		return adminRegRepository.save(adminRegistration);
	}
		
	
	@Transactional
	public void updateAdminRegistration (AdminRegistration adminRegistration) {
		adminRegRepository.save(adminRegistration);	
	
	}
	
	@Transactional
	public void deleteAdminRegistration (int userid) {
		//empRepository.delete(user);	
		System.out.println("service method called");
		adminRegRepository.deleteById(userid);
	
	}
	@Transactional 
	  public AdminRegistration  getUser(int id) { 
	  Optional<AdminRegistration > optional= adminRegRepository.findById(id);
	  AdminRegistration  adminRegistration =optional.get();
	  return adminRegistration ; 
	  

}
	public AdminRegistration getAdminRegistration(int userid) {
		// TODO Auto-generated method stub
		return null;
	}
	
}