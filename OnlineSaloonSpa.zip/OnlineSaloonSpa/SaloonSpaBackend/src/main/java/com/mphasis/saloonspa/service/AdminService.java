package com.mphasis.saloonspa.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.AdminRepository;
import com.mphasis.saloonspa.model.Admin;



@Service
public class AdminService {
	//@org.springframework.beans.factory.annotation.Autowired(required=true)

	@Autowired
	AdminRepository admRepository;
	
	@Transactional
	public List<Admin> fetchAdmine() {
		List<Admin> admList=admRepository.findAll();
		return admList;
		
	}
	@Transactional
	public Admin saveAdmin(Admin admin) {
		
		return admRepository.save(admin);
		
	}
	@Transactional
	public void updateAdmin(Admin adm) {
		admRepository.save(adm);	
	
	}
	
	@Transactional
	public void deleteAdmin(int admserviceid) {
		//admRepository.delete(adm);	
		System.out.println("service method called");
		admRepository.deleteById(admserviceid);
	
	}
	@Transactional 
	  public Admin getAdmin(int serviceid) { 
	  
	Optional<Admin> optional= admRepository.findById(serviceid);
	  Admin adm=optional.get();
	  return adm;
	  

}
}
