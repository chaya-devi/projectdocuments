package com.mphasis.saloonspa.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.AdminRepository;
import com.mphasis.saloonspa.dao.BookingRepository;
import com.mphasis.saloonspa.model.Admin;
import com.mphasis.saloonspa.model.Booking;



@Service
public class BookingService {
	//@org.springframework.beans.factory.annotation.Autowired(required=true)

	@Autowired
	BookingRepository bkRepository;
	
	@Transactional
	public List<Booking> fetchBoooking() {
		List<Booking> bkList=bkRepository.findAll();
		return bkList;
		
	}
	@Transactional
	public Booking saveBooking(Booking booking) {
		
		return bkRepository.save(booking);
		
	}
	@Transactional
	public void updateBooking(Booking bk) {
		bkRepository.save(bk);	
	
	}
	
	@Transactional
	public void deleteBooking(int bkuserid) {
		//admRepository.delete(adm);	
		System.out.println("service method called");
		bkRepository.deleteById(bkuserid);
	
	}
	@Transactional 
	  public Booking getBooking(int userid) { 
	  
	Optional<Booking> optional= bkRepository.findById(userid);
	  Booking bk=optional.get();
	  return bk;
	  

}
}
