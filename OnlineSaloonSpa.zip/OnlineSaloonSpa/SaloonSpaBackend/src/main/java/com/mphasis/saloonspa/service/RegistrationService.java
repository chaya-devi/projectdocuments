package com.mphasis.saloonspa.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.RegistrationRepository;
import com.mphasis.saloonspa.model.Registration;

@Service
public class RegistrationService {
	
	@Autowired
	RegistrationRepository regRepository;
	
	@Transactional
	public List<Registration> fetchRegistration() {
		List<Registration> regList=regRepository.findAll();
		return regList;
		
	}
	@Transactional
	public Registration saveRegistration(Registration registration) {
		
		return regRepository.save(registration);
		
	}

}
