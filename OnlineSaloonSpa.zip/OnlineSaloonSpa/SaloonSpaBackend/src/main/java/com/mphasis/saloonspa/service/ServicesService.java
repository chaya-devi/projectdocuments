package com.mphasis.saloonspa.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.ServicesRepository;
import com.mphasis.saloonspa.model.Services;

@Service
public class ServicesService {

	@Autowired
	ServicesRepository servicesRepository;
	
	@Transactional
	public List<Services> fetchServices() {
		List<Services> servicesList=servicesRepository.findAll();
		return servicesList;
		
	}
	@Transactional
	public Services saveServices(Services services) {
		
		return servicesRepository.save(services);
		
	}
	@Transactional
	public void updateServices(Services services) {
		servicesRepository.save(services);	
	
	}
	
	@Transactional
	public void deleteServices(int serviceId) {
		//pgRepository.delete(pg);	
		System.out.println("service method called");
		servicesRepository.deleteById(serviceId);
	
	}
	@Transactional 
	  public Services getServices(int id) { 
	  Optional<Services> optional= servicesRepository.findById(id);
	  Services services=optional.get();
	  return services;
	  

}
}

