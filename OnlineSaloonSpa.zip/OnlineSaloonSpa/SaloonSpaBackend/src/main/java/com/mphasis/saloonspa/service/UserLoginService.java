package com.mphasis.saloonspa.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.saloonspa.dao.UserLoginRepository;
import com.mphasis.saloonspa.model.UserLogin;

@Service
public class UserLoginService {

	@Autowired
	UserLoginRepository userloginRepository;

	public UserLogin validateUserLogin(UserLogin userlogin) {
		UserLogin ul=userloginRepository.validateUserLogin(userlogin.getUserid(),userlogin.getPassword());
		
		return ul;
	}
	
}