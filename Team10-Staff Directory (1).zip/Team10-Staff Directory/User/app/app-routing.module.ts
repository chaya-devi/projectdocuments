import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FunctionsComponent } from './functions/functions.component';
import { LoginComponent } from './login/login.component';
import { StaffComponent } from './staff/staff.component';

const routes: Routes = [
{path: 'functions',component:FunctionsComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export  const routingComponents = [LoginComponent]