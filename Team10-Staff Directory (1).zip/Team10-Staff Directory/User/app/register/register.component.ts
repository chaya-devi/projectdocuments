import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private studentService: StudentService) { }
  register(registerForm : NgForm)
  {
    this.studentService.registerUser(registerForm.value).subscribe(
      (resp)=>{
        console.log(resp);
        registerForm.reset();
      }
      
    );
  }

  ngOnInit(): void {
  }

}
