export class Staff {
    id: number;
    dname: string;
    name: string;
    gender: string;
    did: number;
}