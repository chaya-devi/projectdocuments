import { Component, OnInit } from '@angular/core';
import { Staff } from '../staff';
import { UserService } from '../user.service';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {
  staffs: Staff[];
  constructor(private userService:UserService ) { }

  ngOnInit(): void {
    this.userService.getStaffs().subscribe((data:Staff[])=>{
      console.log(data);
     this.staffs=data;
    });
  }

}
