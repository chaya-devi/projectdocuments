package com.staff.bean;

import java.util.Date;

public class UserWrapper {
	private String UserName;
	 private int UserId;
	 private String Gender;
	 private String Gmail;
	 private String Password;
	 
	 
	public String getUserName() {  
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	
	public int getUserId() {
		return UserId;
	}
	public void setUserId(int userId) {
		UserId = userId;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getGmail() {
		return Gmail;
	}
	public void setGmail(String gmail) {
		Gmail = gmail;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	
	 
}
