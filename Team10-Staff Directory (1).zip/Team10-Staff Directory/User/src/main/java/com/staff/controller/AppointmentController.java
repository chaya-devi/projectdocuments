package com.staff.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.staff.exception.ResourceNotFoundException;
import com.staff.model.BookAppointment;

import com.staff.service.AppoinService;

@RestController
public class AppointmentController {
	@Autowired
	AppoinService as;
	
	@PostMapping("/saveAppointment")
	public BookAppointment addAppointment(@RequestBody BookAppointment bk) {
        
		BookAppointment appointment = as.saveApp(bk);
		return appointment;
	}
	@GetMapping("/getapp/{appId}")
	public ResponseEntity<BookAppointment> getAppById(@PathVariable("appId") int appId)
			throws ResourceNotFoundException {
		BookAppointment boap = as.getApp(appId);
		return ResponseEntity.ok().body(boap);
	}
}
