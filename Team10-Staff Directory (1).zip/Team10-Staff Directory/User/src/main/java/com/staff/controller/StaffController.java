package com.staff.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.staff.exception.ResourceNotFoundException;
import com.staff.model.ViewStaff;
import com.staff.service.StaffService;
@CrossOrigin(origins ="http://localhost:4200")
@RestController
public class StaffController {
	@Autowired
	StaffService staffser;
	
	@GetMapping("/getAllStaff")
	public List<ViewStaff> getEmployees() {
		List<ViewStaff> staffList = staffser.fetchEmployees();

		return staffList;

	}
	@GetMapping("/getstaff/{staffId}")
	public ResponseEntity<ViewStaff> getStaffById(@PathVariable("staffId") int staffId)
			throws ResourceNotFoundException {
		ViewStaff staff = staffser.getStaff(staffId);
		return ResponseEntity.ok().body(staff);
	}
	

}
