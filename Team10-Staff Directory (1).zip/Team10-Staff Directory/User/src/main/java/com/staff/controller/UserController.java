package com.staff.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.staff.bean.UserWrapper;
import com.staff.model.UserRegister;
import com.staff.service.UserService;
@CrossOrigin(origins ="http://localhost:4200")
@RestController
public class UserController {

    @Autowired
    UserService userservice;
    
 
 	@PostMapping("/saveUser/")
 	public UserRegister addUser(@RequestBody UserRegister reg) {

 		UserRegister register = userservice.saveUser(reg);

 		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
 		return register;
 	}
 	//http://localhost:8080//loginUser
 			@PostMapping("/loginUser")
 			public ResponseEntity<Object> validateUser(@RequestBody UserRegister user) 		
 			{
 				UserRegister p = userservice.validateUser(user);
 				if (p==null)
 				
 				return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
 				else
 					return new ResponseEntity<>("Successful login", HttpStatus.OK);
 			}
	
//	 @PostMapping("/saveUser")
//      public ResponseEntity<UserWrapper> saveUser(@RequestBody UserWrapper userwrapper)
//      {
//		 userwrapper=userservice.saveUser(userwrapper);
//		  return ResponseEntity.ok(userwrapper);
//      }
}
