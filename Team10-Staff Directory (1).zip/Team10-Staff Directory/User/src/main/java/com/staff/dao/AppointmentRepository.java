package com.staff.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.staff.model.BookAppointment;
@Repository
public interface AppointmentRepository extends JpaRepository<BookAppointment, Integer> {

}
