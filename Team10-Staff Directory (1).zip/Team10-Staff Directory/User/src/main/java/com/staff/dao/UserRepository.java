package com.staff.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.stereotype.Repository;

import com.staff.model.UserRegister;

@Repository
public interface UserRepository extends JpaRepository<UserRegister,Integer>{
	@Query("SELECT us FROM UserRegister us WHERE us.UserName =?1 and us.Password=?2")
	public UserRegister validateUser(String username,String password);
}
