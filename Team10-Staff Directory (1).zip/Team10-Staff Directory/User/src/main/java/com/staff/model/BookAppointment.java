package com.staff.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="appointment_table") 
public class BookAppointment {
	@Id
	@GeneratedValue
	@Column(name="AppointmentId")
	private int Aid;
	@Column(name="UserName")
	private String uname;
	@Column(name="StaffId")
	private int staffId;
	@Column(name="Appointment_Date")
	@Temporal(TemporalType.DATE)
	private Date Adate;
	@Column(name="Appointment_Time")
	@Temporal(TemporalType.DATE)
	private Date Atime;
	public BookAppointment(int aid, String uname, int staffId, Date adate, Date atime) {
		super();
		Aid = aid;
		this.uname = uname;
		this.staffId = staffId;
		Adate = adate;
		Atime = atime;
	}
	
	public BookAppointment() {
		super();
	}

	public int getAid() {
		return Aid;
	}
	public void setAid(int aid) {
		Aid = aid;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getStaffId() {
		return staffId;
	}
	public void setStaffId(int staffId) {
		this.staffId = staffId;
	}
	public Date getAdate() {
		return Adate;
	}
	public void setAdate(Date adate) {
		Adate = adate;
	}
	public Date getAtime() {
		return Atime;
	}
	public void setAtime(Date atime) {
		Atime = atime;
	}
	
	

}
