package com.staff.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="registration")
public class UserRegister {
	         
	         @Column(name="UserName")
		     private String UserName;
	         @Id
	         @GeneratedValue
	         @Column(name="UserId")
		     private int UserId;
		    
			@Column(name="Gender")
	         private String Gender;
		     
		     @Column(name="EmailID")
	         private String Gmail;
		     @Column(name="Password")
	         private String Password;
		     


		public UserRegister(String userName, int userId, String gender, String gmail, String password) {
				super();
				UserName = userName;
				UserId = userId;
				Gender = gender;
				Gmail = gmail;
				Password = password;
			}
		
		public UserRegister() {
			super();
		}

		public String getUserName() {
				return UserName;
			}
			public void setUserName(String userName) {
				UserName = userName;
			}
			 public int getUserId() {
					return UserId;
				}
				public void setUserId(int userId) {
					UserId = userId;
				}
				
			
			public String getGender() {
				return Gender;
			}
			public void setGender(String gender) {
				Gender = gender;
			}
			public String getGmail() {
				return Gmail;
			}
			public void setGmail(String gmail) {
				Gmail = gmail;
			}
			public String getPassword() {
				return Password;
			}
			public void setPassword(String password) {
				Password = password;
			}
			
		     
}
