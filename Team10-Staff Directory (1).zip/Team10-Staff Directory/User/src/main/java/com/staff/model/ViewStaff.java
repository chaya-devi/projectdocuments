package com.staff.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Table(name="staff")
@Entity
public class ViewStaff {
	      @Id
	      @Column(name="staffid")
          private int id;
	      @Column(name="StaffName")
          private String Name;
	      private String dname;
	      @Column(name="Gender")
          private String Gender;
	      @Column(name="DeptId")
	      
          private int Did;
		  
		public ViewStaff(int id, String name, String dname, String gender, int did) {
			super();
			this.id = id;
			Name = name;
			this.dname = dname;
			Gender = gender;
			Did = did;
		}
		
		public ViewStaff() {
			super();
		}

		public String getDname() {
			return dname;
		}
		public void setDname(String dname) {
			this.dname = dname;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		
		public String getGender() {
			return Gender;
		}
		public void setGender(String gender) {
			Gender = gender;
		}
		public int getDid() {
			return Did;
		}
		public void setDid(int did) {
			Did = did;
		}
	      
	      
}
