package com.staff.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.staff.dao.AppointmentRepository;
import com.staff.model.BookAppointment;


@Service
public class AppoinService {
	@Autowired
	AppointmentRepository arep;
	
	 @Transactional
	 	public BookAppointment saveApp(BookAppointment bookapp) {
	 		
	 		return arep.save(bookapp);
	 		
	 		
	 	}
	 @Transactional 
	  public BookAppointment getApp(int id) { 
	  Optional<BookAppointment> optional= arep.findById(id);
	  BookAppointment  bokap=optional.get();
	  return bokap;
	  

}

}
