package com.staff.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.staff.dao.ViewStaffRepository;
import com.staff.model.ViewStaff;

@Service
public class StaffService {
	
	@Autowired
	ViewStaffRepository staffrepos;
	
	@Transactional
	public List<ViewStaff> fetchEmployees() {
		List<ViewStaff> staffList=staffrepos.findAll();
		return staffList;
		
	}
	@Transactional 
	  public ViewStaff getStaff(int id) { 
	  Optional<ViewStaff> optional= staffrepos.findById(id);
	  ViewStaff staff=optional.get();
	  return staff;
	  

}
	
	


}
