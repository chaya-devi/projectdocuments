package com.staff.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.staff.bean.UserWrapper;
import com.staff.dao.UserRepository;
import com.staff.model.UserRegister;

@Service
public class UserService {
     @Autowired
      UserRepository repository;
     
     @Transactional
 	public UserRegister saveUser(UserRegister reg) {
 		
 		return repository.save(reg);
 		
 		
 	}
     @Transactional
		public UserRegister validateUser(UserRegister user) {
    	 UserRegister us=repository.validateUser(user.getUserName(),user.getPassword());
			
			return us;
		}
     
     
//     @Transactional
//	public UserWrapper saveUser(UserWrapper userwr)
//	{
//		UserRegister user=new UserRegister();
//		user.setUserName(userwr.getUserName());
//		user.setUserId(userwr.getUserId());
//		user.setGender(userwr.getGender());
//		user.setGmail(userwr.getGmail());
//		user.setPassword(userwr.getPassword());
//		user=repository.save(user);
//		
//		userwr.setUserName(user.getUserName());	
//		userwr.setUserId(user.getUserId());
//		userwr.setGender(user.getGender());
//		userwr.setGmail(user.getGmail());
//		userwr.setPassword(user.getPassword());
//		
//		return userwr;
//	}
}
