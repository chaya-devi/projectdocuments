package com.staff.staffproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaffprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
