package com.mphasis.vehicleRentalSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.vehicleRentalSystem.domain.Admin;

import com.mphasis.vehicleRentalSystem.service.AdminService;


@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v2")
public class AdminController {
	 @Autowired
	  AdminService adminService;
	 @GetMapping("/getAllAdmin")
	  public List<Admin> getAdmin() {
			List<Admin> adminList = adminService.fetchAdmins();

			return adminList;

		}
	 @PostMapping("/saveAdmin")
	  public Admin addAdmin(@RequestBody Admin admin) {

			Admin admins = adminService.saveAdmin(admin);

			// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
			return admins;
	    }
	 @PostMapping("/loginAdmin")
		public ResponseEntity<Object> validateAdmin(@RequestBody Admin admin) 		
		{
			Admin a = adminService.validateAdmin(admin);
			if (a==null)
			
			return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>("Successful login", HttpStatus.OK);
		}

}
