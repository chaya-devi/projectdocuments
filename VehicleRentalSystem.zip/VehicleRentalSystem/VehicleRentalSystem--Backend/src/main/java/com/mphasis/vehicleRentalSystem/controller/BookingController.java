package com.mphasis.vehicleRentalSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.vehicleRentalSystem.domain.Booking;
import com.mphasis.vehicleRentalSystem.exception.ResourceNotFoundException;
import com.mphasis.vehicleRentalSystem.service.BookingService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v2")
public class BookingController {
	  @Autowired
	  BookingService bookingService;
	  
	  @GetMapping("/getAllBookings")
	  public List<Booking> getBookings() {
			List<Booking> bookingList = bookingService.fetchBookings();

			return bookingList;

		}
	  @GetMapping("/getBooking/{bookingId}")
			public ResponseEntity<Booking> getBookingById(@PathVariable("bookingId") int bookingId)
					throws ResourceNotFoundException {
				Booking booking = bookingService.getBooking(bookingId);
				return ResponseEntity.ok().body(booking);
			}
	  @PostMapping("/saveBookings")
	  public Booking addBooking(@RequestBody Booking booking) {

			Booking bookings = bookingService.saveBooking(booking);

			// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
			return bookings;
	    }
	  @PutMapping("/updateBooking/{bookingId}")
		public ResponseEntity<Booking> updateEmployee(@PathVariable("bookingId") int bookingId,
				@RequestBody Booking bookingDetails) throws ResourceNotFoundException {
			Booking booking = bookingService.getBooking(bookingId);

			booking.setBookingDateTime(bookingDetails.getBookingDateTime());
			booking.setPickupDateTime(bookingDetails.getPickupDateTime());
			booking.setReturnDateTime(bookingDetails.getReturnDateTime());
			booking.setVehicleId(bookingDetails.getVehicleId());
			booking.setUserId(bookingDetails.getUserId());
			final Booking updatedBooking = bookingService.saveBooking(booking);
			return ResponseEntity.ok(updatedBooking);
		}
	  @DeleteMapping(value = "/deleteBooking/{bookingId}")
		public ResponseEntity<Object> deleteBooking(@PathVariable("bookingId") int bookingId) {

			bookingService.deleteBooking(bookingId);
			return new ResponseEntity<>("Booking deleted successsfully", HttpStatus.OK);
		}



}
