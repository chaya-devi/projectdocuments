package com.mphasis.vehicleRentalSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.mphasis.vehicleRentalSystem.domain.Feedback;
import com.mphasis.vehicleRentalSystem.exception.ResourceNotFoundException;

import com.mphasis.vehicleRentalSystem.service.FeedbackService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v2")
public class FeedbackController {
	 @Autowired
	  FeedbackService feedbackService;
	  
	  @GetMapping("/getAllFeedbacks")
	  public List<Feedback> getFeedbacks() {
			List<Feedback> feedbackList = feedbackService.fetchFeedbacks();

			return feedbackList;

		}
	  @GetMapping("/getFeedback/{feedbackId}")
			public ResponseEntity<Feedback> getFeedbackById(@PathVariable("feedbackId") int feedbackId)
					throws ResourceNotFoundException {
		  Feedback feedback = feedbackService.getFeedback(feedbackId);
				return ResponseEntity.ok().body(feedback);
			}
	  @PostMapping("/saveFeedbacks")
	  public Feedback addFeedback(@RequestBody Feedback feedback) {

		  Feedback feedbacks = feedbackService.saveFeedback(feedback);

			// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
			return feedbacks;
	    }
	  @PutMapping("/updateFeedback/{feedbackId}")
		public ResponseEntity<Feedback> updateFeedback(@PathVariable("feedbackId") int feedbackId,
				@RequestBody Feedback feedbackDetails) throws ResourceNotFoundException {
		  Feedback feedback = feedbackService.getFeedback(feedbackId);

		  feedback.setFeedback(feedbackDetails.getFeedback());
			
		  feedback.setVehicleId(feedbackDetails.getVehicleId());
		  feedback.setUserId(feedbackDetails.getUserId());
			final Feedback updatedFeedback = feedbackService.saveFeedback(feedback);
			return ResponseEntity.ok(updatedFeedback);
		}
	  @DeleteMapping(value = "/deleteFeedback/{feedbackId}")
		public ResponseEntity<Object> deleteFeedback(@PathVariable("feedbackId") int feedbackId) {

		  feedbackService.deleteFeedback(feedbackId);
			return new ResponseEntity<>("feedback deleted successsfully", HttpStatus.OK);
		}
}
