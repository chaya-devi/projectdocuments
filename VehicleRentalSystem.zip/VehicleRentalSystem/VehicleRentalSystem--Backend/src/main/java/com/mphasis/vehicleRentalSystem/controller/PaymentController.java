package com.mphasis.vehicleRentalSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.vehicleRentalSystem.domain.Booking;
import com.mphasis.vehicleRentalSystem.domain.Payment;
import com.mphasis.vehicleRentalSystem.exception.ResourceNotFoundException;
import com.mphasis.vehicleRentalSystem.service.BookingService;
import com.mphasis.vehicleRentalSystem.service.PaymentService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v2")
public class PaymentController {
	@Autowired
	PaymentService paymentService;
	  
	  @GetMapping("/getAllPayments")
	  public List<Payment> getPayments() {
			List<Payment> paymentList = paymentService.fetchPayments();

			return paymentList;

		}
	  @GetMapping("/getPayment/{paymentId}")
			public ResponseEntity<Payment> getPaymentById(@PathVariable("paymentId") int paymentId)
					throws ResourceNotFoundException {
		  Payment payment =paymentService.getPayment(paymentId);
				return ResponseEntity.ok().body(payment);
			}
	  @PostMapping("/savePayments")
	  public Payment addPayment(@RequestBody Payment payment) {

		  Payment payments = paymentService.savePayment(payment);

			// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
			return payments;
	    }
	  @PutMapping("/updatePayment/{paymentId}")
		public ResponseEntity<Payment> updatePayment(@PathVariable("paymentId") int paymentId,
				@RequestBody Payment paymentDetails) throws ResourceNotFoundException {
		  Payment payment = paymentService.getPayment(paymentId);

		  payment.setPaymentDateTime(paymentDetails.getPaymentDateTime());
		  payment.setPaymentType(paymentDetails.getPaymentType());
		  payment.setIsConfirm(paymentDetails.getIsConfirm());
		  payment.setNoOfDays(paymentDetails.getNoOfDays());
		  payment.setAmount(paymentDetails.getAmount());
		  payment.setVehicleId(paymentDetails.getVehicleId());
		  payment.setUserId(paymentDetails.getUserId());
			
			final Payment updatedPayment =  paymentService.savePayment(payment);
			return ResponseEntity.ok(updatedPayment);
		}
	  @DeleteMapping(value = "/deletePayment/{paymentId}")
		public ResponseEntity<Object> deletePayment(@PathVariable("paymentId") int paymentId) {

		  paymentService.deletePayment(paymentId);
			return new ResponseEntity<>("Payment deleted successsfully", HttpStatus.OK);
		}



}
