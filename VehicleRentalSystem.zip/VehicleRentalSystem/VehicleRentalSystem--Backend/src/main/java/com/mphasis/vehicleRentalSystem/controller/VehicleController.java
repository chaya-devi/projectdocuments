package com.mphasis.vehicleRentalSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.mphasis.vehicleRentalSystem.domain.Vehicle;
import com.mphasis.vehicleRentalSystem.exception.ResourceNotFoundException;

import com.mphasis.vehicleRentalSystem.service.VehicleService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v2")
public class VehicleController {
	 @Autowired
	  VehicleService vehicleService;
	  
	  @GetMapping("/getAllVehicles")
	  public List<Vehicle> getVehicles() {
			List<Vehicle> vehicleList = vehicleService.fetchVehicles();

			return vehicleList;

		}
	  @GetMapping("/getVehicle/{vehicleId}")
		public ResponseEntity<Vehicle> getVehicleById(@PathVariable("vehicleId") String vehicleId)
				throws ResourceNotFoundException {
			Vehicle vehicle = vehicleService.getVehicle(vehicleId);
			return ResponseEntity.ok().body(vehicle);
		}
	  
	  @PostMapping("/saveVehicles")
	  public Vehicle addVehicle(@RequestBody Vehicle vehicle) {

		  Vehicle vehicles = vehicleService.saveVehicle(vehicle);

			// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
			return vehicles;
	    }
	  @PutMapping("/updateVehicle/{vehicleId}")
		public ResponseEntity<Vehicle> updateVehicle(@PathVariable("vehicleId") String vehicleId,
				@RequestBody Vehicle vehicleDetails) throws ResourceNotFoundException {
		  Vehicle vehicle = vehicleService.getVehicle(vehicleId);

		  vehicle.setModelName(vehicleDetails.getModelName());
		  vehicle.setModelYear(vehicleDetails.getModelYear());
		  vehicle.setBrandName(vehicleDetails.getBrandName());
		  vehicle.setDailyPrice(vehicleDetails.getDailyPrice());
		  vehicle.setVehiclePlateNo(vehicleDetails.getVehiclePlateNo());
		  vehicle.setNoOfSeats(vehicleDetails.getNoOfSeats());
		  vehicle.setAvailability(vehicleDetails.getAvailability());
		  vehicle.setVendorId(vehicleDetails.getVendorId());
			final Vehicle updatedVehicle = vehicleService.saveVehicle(vehicle);
			return ResponseEntity.ok(updatedVehicle);
		}
	  @DeleteMapping(value = "/deleteVehicle/{vehicleId}")
		public ResponseEntity<Object> deleteVehicle(@PathVariable("vehicleId") String vehicleId) {

			vehicleService.deleteVehicle(vehicleId);
			return new ResponseEntity<>("Vehicle deleted successsfully", HttpStatus.OK);
		}
	  
}
