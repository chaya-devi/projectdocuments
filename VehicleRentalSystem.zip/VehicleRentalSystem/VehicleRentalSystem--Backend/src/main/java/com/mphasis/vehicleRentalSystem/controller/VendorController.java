package com.mphasis.vehicleRentalSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.mphasis.vehicleRentalSystem.domain.Vendor;
import com.mphasis.vehicleRentalSystem.exception.ResourceNotFoundException;
import com.mphasis.vehicleRentalSystem.service.VendorService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/v2")
public class VendorController {
	 @Autowired
	  VendorService vendorService;
	  
	  @GetMapping("/getAllVendors")
	  public List<Vendor> getVendors() {
			List<Vendor> vendorList = vendorService.fetchVendors();

			return vendorList;

		}
	  @GetMapping("/getVendor/{vendorId}")
		public ResponseEntity<Vendor> getVendorById(@PathVariable("vendorId") int vendorId)
				throws ResourceNotFoundException {
			Vendor vendor = vendorService.getVendor(vendorId);
			return ResponseEntity.ok().body(vendor);
		}
	  @PostMapping("/saveVendors")
	  public Vendor addVendor(@RequestBody Vendor vendor) {

			Vendor vendors = vendorService.saveVendor(vendor);

			// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
			return vendors;
	    }
	  @PutMapping("/updateVendor/{vendorId}")
		public ResponseEntity<Vendor> updateVendor(@PathVariable("vendorId") int vendorId,
				@RequestBody Vendor vendorDetails) throws ResourceNotFoundException {
			Vendor vendor = vendorService.getVendor(vendorId);

			vendor.setVendorName(vendorDetails.getVendorName());
			vendor.setPassword(vendorDetails.getPassword());
			vendor.setEmail(vendorDetails.getEmail());
			vendor.setContact(vendorDetails.getContact());
			vendor.setAddress(vendorDetails.getAddress());
			vendor.setLicense(vendorDetails.getLicense());
			final Vendor updatedVendor = vendorService.saveVendor(vendor);
			return ResponseEntity.ok(updatedVendor);
		}
	  
	  @DeleteMapping(value = "/deleteVendor/{vendorId}")
		public ResponseEntity<Object> deleteVendor(@PathVariable("vendorId") int vendorId) {

			vendorService.deleteVendor(vendorId);
			return new ResponseEntity<>("Vendor deleted successsfully", HttpStatus.OK);
		}
	  
	  @PostMapping("/loginVendor")
		public ResponseEntity<Object> validateVendor(@RequestBody Vendor vendor) 		
		{
			Vendor v = vendorService.validateVendor(vendor);
			if (v==null)
			
			return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>("Successful login", HttpStatus.OK);
		}

}
