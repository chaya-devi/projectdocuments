package com.mphasis.vehicleRentalSystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.vehicleRentalSystem.domain.Admin;


@Repository
public interface AdminRepository extends JpaRepository<Admin, Integer>{
	@Query("SELECT a FROM Admin a WHERE a.adminName =?1 and a.password=?2")
	public Admin validateAdmin(String adminName,String password);
}
