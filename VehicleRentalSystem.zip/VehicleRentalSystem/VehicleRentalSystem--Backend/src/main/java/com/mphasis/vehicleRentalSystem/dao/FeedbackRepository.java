package com.mphasis.vehicleRentalSystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.vehicleRentalSystem.domain.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Integer>{

}
