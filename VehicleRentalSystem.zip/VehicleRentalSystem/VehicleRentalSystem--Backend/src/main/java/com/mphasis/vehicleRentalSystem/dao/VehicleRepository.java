package com.mphasis.vehicleRentalSystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.vehicleRentalSystem.domain.Vehicle;


public interface VehicleRepository extends JpaRepository<Vehicle, String>{

}
