package com.mphasis.vehicleRentalSystem.dao;

import org.springframework.stereotype.Repository;


import com.mphasis.vehicleRentalSystem.domain.Vendor;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
@Repository
public interface VendorRepository extends JpaRepository<Vendor, Integer>{
	@Query("SELECT v FROM Vendor v WHERE v.vendorName =?1 and v.password=?2")
	public Vendor validateVendor(String vendorName,String password);
}
