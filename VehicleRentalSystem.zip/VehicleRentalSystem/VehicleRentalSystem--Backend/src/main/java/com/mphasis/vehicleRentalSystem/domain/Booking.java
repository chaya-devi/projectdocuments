package com.mphasis.vehicleRentalSystem.domain;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="BOOKINGDETAILS")
public class Booking {
	    @Id
	    @GeneratedValue
	    @Column(name = "BOOKINGID")
		private int bookingId;
	    
	    @Column(name = "BOOKINGDATETIME")
	    @Temporal(TemporalType.TIMESTAMP) 
		private java.util.Date bookingDateTime;
	    
		@Column(name="PICKUPDATETIME")
		@Temporal(TemporalType.TIMESTAMP)
		private java.util.Date pickupDateTime;
		
		@Column(name="RETURNDATETIME")
		@Temporal(TemporalType.TIMESTAMP)
		private java.util.Date returnDateTime;
		
		@Column(name = "VEHICLEID")
		private String vehicleId;
		
		
		@Column(name = "USERID")
		private int userId;
		
		public Booking() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Booking(int bookingId, java.util.Date bookingDateTime, java.util.Date pickupDateTime, java.util.Date returnDateTime,
				String vehicleId, int userId) {
			super();
			this.bookingId = bookingId;
			this.bookingDateTime = bookingDateTime;
			this.pickupDateTime = pickupDateTime;
			this.returnDateTime = returnDateTime;
			this.vehicleId = vehicleId;
			this.userId = userId;
		}

		public int getBookingId() {
			return bookingId;
		}

		public void setBookingId(int bookingId) {
			this.bookingId = bookingId;
		}

		public java.util.Date getBookingDateTime() {
			return bookingDateTime;
		}

		public void setBookingDateTime(java.util.Date bookingDateTime) {
			this.bookingDateTime = bookingDateTime;
		}

		public java.util.Date getPickupDateTime() {
			return pickupDateTime;
		}

		public void setPickupDateTime(java.util.Date pickupDateTime) {
			this.pickupDateTime = pickupDateTime;
		}

		public java.util.Date getReturnDateTime() {
			return returnDateTime;
		}

		public void setReturnDateTime(java.util.Date returnDateTime) {
			this.returnDateTime = returnDateTime;
		}

		public String getVehicleId() {
			return vehicleId;
		}

		public void setVehicleId(String vehicleId) {
			this.vehicleId = vehicleId;
		}

		public int getUserId() {
			return userId;
		}

		public void setUserId(int userId) {
			this.userId = userId;
		}

		
		
}
