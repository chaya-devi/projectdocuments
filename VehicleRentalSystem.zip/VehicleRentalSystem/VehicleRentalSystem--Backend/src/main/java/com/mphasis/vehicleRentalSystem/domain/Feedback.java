package com.mphasis.vehicleRentalSystem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FEEDBACKDETAILS")
public class Feedback {
	 @Id
	    @GeneratedValue
	    @Column(name = "FEEDBACKID")
		private int feedbackId;
	 
	 @Column(name = "FEEDBACK")
		private String feedback;
	 
	 @Column(name = "VEHICLEID")
		private String vehicleId;
	 
	 @Column(name = "USERID")
		private int userId;

	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Feedback(int feedbackId, String feedback, String vehicleId, int userId) {
		super();
		this.feedbackId = feedbackId;
		this.feedback = feedback;
		this.vehicleId = vehicleId;
		this.userId = userId;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	 
	 
}
