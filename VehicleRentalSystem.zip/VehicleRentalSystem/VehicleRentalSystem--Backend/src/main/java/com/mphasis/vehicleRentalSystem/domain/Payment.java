package com.mphasis.vehicleRentalSystem.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="PAYMENTDETAILS")
public class Payment {
	@Id
    @GeneratedValue
    @Column(name = "PAYMENTID")
	private int paymentId;
	
	@Column(name = "PAYMENTDATETIME")
    @Temporal(TemporalType.TIMESTAMP) 
	private java.util.Date paymentDateTime;
	
	@Column(name = "PAYMENTTYPE")
	private String paymentType;
	
	@Column(name = "ISCONFIRM")
	private String isConfirm;
	
	@Column(name = "NOOFDAYS")
	private int noOfDays;
	
	@Column(name = "AMOUNT")
	private int amount;
	
	@Column(name = "VEHICLEID")
	private String vehicleId;
	
	@Column(name = "USERID")
	private int userId;

	public Payment(int paymentId, Date paymentDateTime, String paymentType, String isConfirm, int noOfDays, int amount,
			String vehicleId, int userId) {
		super();
		this.paymentId = paymentId;
		this.paymentDateTime = paymentDateTime;
		this.paymentType = paymentType;
		this.isConfirm = isConfirm;
		this.noOfDays = noOfDays;
		this.amount = amount;
		this.vehicleId = vehicleId;
		this.userId = userId;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public java.util.Date getPaymentDateTime() {
		return paymentDateTime;
	}

	public void setPaymentDateTime(java.util.Date paymentDateTime) {
		this.paymentDateTime = paymentDateTime;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getIsConfirm() {
		return isConfirm;
	}

	public void setIsConfirm(String isConfirm) {
		this.isConfirm = isConfirm;
	}

	public int getNoOfDays() {
		return noOfDays;
	}

	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
}
