package com.mphasis.vehicleRentalSystem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VEHICLEDETAILS")
public class Vehicle {
	 @Id
	 @Column(name = "VEHICLEID")
	 private String vehicleId;
	 @Column(name = "MODELNAME")
	 private String modelName;
	 @Column(name = "MODELYEAR")
	 private int modelYear;
	 @Column(name = "BRANDNAME")
	 private String brandName;
	 @Column(name = "DAILYPRICE")
	 private int dailyPrice;
	 @Column(name = "VEHICLEPLATENO")
	 private String vehiclePlateNo;
	 @Column(name = "NOOFSEATS")
	 private int noOfSeats;
	 @Column(name = "AVAILABILITY")
	 private String availability;
	 @Column(name = "VENDORID")
	 private int vendorId;
	public Vehicle(String vehicleId, String modelName, int modelYear, String brandName, int dailyPrice,
			String vehiclePlateNo, int noOfSeats, String availability, int vendorId) {
		super();
		this.vehicleId = vehicleId;
		this.modelName = modelName;
		this.modelYear = modelYear;
		this.brandName = brandName;
		this.dailyPrice = dailyPrice;
		this.vehiclePlateNo = vehiclePlateNo;
		this.noOfSeats = noOfSeats;
		this.availability = availability;
		this.vendorId = vendorId;
	}
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public int getModelYear() {
		return modelYear;
	}
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public int getDailyPrice() {
		return dailyPrice;
	}
	public void setDailyPrice(int dailyPrice) {
		this.dailyPrice = dailyPrice;
	}
	public String getVehiclePlateNo() {
		return vehiclePlateNo;
	}
	public void setVehiclePlateNo(String vehiclePlateNo) {
		this.vehiclePlateNo = vehiclePlateNo;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public int getVendorId() {
		return vendorId;
	}
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	 
}
