package com.mphasis.vehicleRentalSystem.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="VENDORDETAILS")
public class Vendor {
	@Id
    
    @Column(name = "VENDORID")
	private int vendorId;
    @Column(name = "VENDORNAME")
	private String vendorName;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="EMAIL")
	private String email;
	@Column(name="CONTACT")
	private long contact;
	@Column(name="ADDRESS")
	private String address;
	@Column(name="LICENSE")
	private String license;
	public Vendor(int vendorId, String vendorName, String password, String email, long contact, String address,
			String license) {
		super();
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.password = password;
		this.email = email;
		this.contact = contact;
		this.address = address;
		this.license = license;
	}
	public Vendor() {
		
	}
	public Vendor(String vendorName, String password) {
		this.vendorName=vendorName;
		this.password=password;
	}
	public int getVendorId() {
		return vendorId;
	}
	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	
}
