package com.mphasis.vehicleRentalSystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.vehicleRentalSystem.dao.AdminRepository;
import com.mphasis.vehicleRentalSystem.domain.Admin;



@Service
public class AdminService {
	@Autowired
	AdminRepository adminRepository;
	@Transactional
	public List<Admin> fetchAdmins() {
		List<Admin> adminList=adminRepository.findAll();
		return adminList;	
	}
	@Transactional
	public Admin saveAdmin(Admin admin) {
		
		return adminRepository.save(admin);
		
	}
	/*@Transactional
	public void updateAdmin(Admin admin) {
	adminRepository.save(admin);	
	
	}*/
	@Transactional
	public Admin validateAdmin(Admin admin) {
		Admin a=adminRepository.validateAdmin(admin.getAdminName(),admin.getPassword());
		
		return a;
	}
}
