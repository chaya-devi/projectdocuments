package com.mphasis.vehicleRentalSystem.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.vehicleRentalSystem.dao.PaymentRepository;

import com.mphasis.vehicleRentalSystem.domain.Payment;

@Service
public class PaymentService {
	@Autowired
	PaymentRepository paymentRepository;
	@Transactional
	public List<Payment> fetchPayments() {
		List<Payment> paymentList=paymentRepository.findAll();
		return paymentList;
		
	}
	@Transactional
	public Payment savePayment(Payment payment) {
		
		return paymentRepository.save(payment);
		
	}
	@Transactional
	public void updatePayment(Payment payment) {
		paymentRepository.save(payment);	
	
	}
	@Transactional
	public void deletePayment(int paymentId) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
		paymentRepository.deleteById(paymentId);
	
	}
	@Transactional 
	  public Payment getPayment(int id) { 
	  Optional<Payment> optional= paymentRepository.findById(id);
	  Payment payment=optional.get();
	  return payment;
	  

}
}
