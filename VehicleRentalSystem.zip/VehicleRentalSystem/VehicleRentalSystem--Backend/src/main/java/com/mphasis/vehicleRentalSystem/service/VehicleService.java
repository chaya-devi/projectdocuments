package com.mphasis.vehicleRentalSystem.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mphasis.vehicleRentalSystem.dao.VehicleRepository;

import com.mphasis.vehicleRentalSystem.domain.Vehicle;

@Service
public class VehicleService {
	@Autowired
	VehicleRepository vehicleRepository;
	@Transactional
	public List<Vehicle> fetchVehicles() {
		List<Vehicle> vehicleList=vehicleRepository.findAll();
		return vehicleList;
		
	}
	@Transactional
	public Vehicle saveVehicle(Vehicle vehicle) {
		
		return vehicleRepository.save(vehicle);
		
	}
	@Transactional
	public void updateVehicle(Vehicle vehicle) {
	vehicleRepository.save(vehicle);	
	
	}
	@Transactional
	public void deleteVehicle(String vehicleId) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
	vehicleRepository.deleteById(vehicleId);
	
	}
	@Transactional 
	  public Vehicle getVehicle(String vehicleId) { 
	  Optional<Vehicle> optional= vehicleRepository.findById(vehicleId);
	  Vehicle vehicle=optional.get();
	  return vehicle;

}
}
