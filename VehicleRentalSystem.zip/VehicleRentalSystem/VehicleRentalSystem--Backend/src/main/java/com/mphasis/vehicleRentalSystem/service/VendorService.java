package com.mphasis.vehicleRentalSystem.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.mphasis.vehicleRentalSystem.dao.VendorRepository;

import com.mphasis.vehicleRentalSystem.domain.Vendor;

@Service
public class VendorService {
	@Autowired
	VendorRepository vendorRepository;
	@Transactional
	public List<Vendor> fetchVendors() {
		List<Vendor> vendorList=vendorRepository.findAll();
		return vendorList;
		
	}
	@Transactional
	public Vendor saveVendor(Vendor vendor) {
		
		return vendorRepository.save(vendor);
		
	}
	@Transactional
	public void updateVendor(Vendor vendor) {
	vendorRepository.save(vendor);	
	
	}
	@Transactional
	public void deleteVendor(int vendorId) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
	vendorRepository.deleteById(vendorId);
	
	}
	@Transactional 
	  public Vendor getVendor(int id) { 
	  Optional<Vendor> optional= vendorRepository.findById(id);
	  Vendor vendor=optional.get();
	  return vendor;

}
	@Transactional
	public Vendor validateVendor(Vendor vendor) {
		Vendor v=vendorRepository.validateVendor(vendor.getVendorName(),vendor.getPassword());
		
		return v;
	}
	
	
}
