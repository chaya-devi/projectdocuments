import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private baseUrl = 'http://localhost:9080/api/v2';

  constructor(private http: HttpClient) { }
  getAdmins(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllAdmins');
  }
  getAdmin(adminId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getAdmin/${adminId}`);
  }

  createAdmin(admin: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveAdmin', admin);
  }

  updateAdmin(adminId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateAdmin/${adminId}`, value);
  }

  deleteAdmin(adminId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteAdmin/${adminId}`, { responseType: 'text' });
  }


}
