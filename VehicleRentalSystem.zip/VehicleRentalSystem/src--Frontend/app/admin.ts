export class Admin{
    adminId:number=0;
    adminName:string="";
    password:string="";
    email:string="";
}