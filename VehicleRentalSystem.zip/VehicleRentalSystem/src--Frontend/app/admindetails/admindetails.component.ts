import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admindetails',
  templateUrl: './admindetails.component.html',
  styleUrls: ['./admindetails.component.css']
})
export class AdmindetailsComponent implements OnInit {

  adminId: number=0;
  admin: Admin=new Admin();

  constructor(private route: ActivatedRoute,private router: Router,private adminService: AdminService) { }

  ngOnInit(): void {
    this.admin = new Admin();

    this.adminId = this.route.snapshot.params['adminId'];
    
    this.adminService.getAdmin(this.adminId)
      .subscribe(data => {
        console.log(data)
        this.admin = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['admins']);
  }

  

}
