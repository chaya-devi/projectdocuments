import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-adminlist',
  templateUrl: './adminlist.component.html',
  styleUrls: ['./adminlist.component.css']
})
export class AdminlistComponent implements OnInit {
 admins: Observable<Admin[]>=new Observable;

  constructor(private adminService: AdminService,private router: Router) { }

  ngOnInit(): void {
    this.getAdmins();
  }

  getAdmins()
  {
    this.admins=this.adminService.getAdmins();
  }
  
  deleteAdmin(adminId: number) {
    this.adminService.deleteAdmin(adminId)
      .subscribe(
        data => {
          console.log(data);
          this.getAdmins();
        },
        error => console.log(error));
  }

  adminDetails(adminId: number){
    this.router.navigate(['details', adminId]);
  }
  updateAdmin(adminId: number)
  {
    this.router.navigate(['update', adminId]);

  }

}
