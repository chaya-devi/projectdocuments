import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import { AdminlistComponent } from './adminlist/adminlist.component';
import { CreateadminComponent } from './createadmin/createadmin.component';
import { CreateuserComponent } from './createuser/createuser.component';
import { CreatevendorComponent } from './createvendor/createvendor.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { UpdateadminComponent } from './updateadmin/updateadmin.component';
import { UpdateuserComponent } from './updateuser/updateuser.component';
import { UpdatevendorComponent } from './updatevendor/updatevendor.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { UserlistComponent } from './userlist/userlist.component';
import { VendordetailsComponent } from './vendordetails/vendordetails.component';
import { VendorlistComponent } from './vendorlist/vendorlist.component';

const routes: Routes = [
  {path:'', redirectTo:'home', pathMatch:'full'},
  {path:'home', component:HomeComponent},
  {path:'signup', component:CreateuserComponent},
  {path:'users', component:UserlistComponent},
  {path:'updateUser/:userId', component:UpdateuserComponent},
  {path:'detailsUser/:userId',component: UserdetailsComponent},
  {path:'adminsignup',component:CreateadminComponent},
  {path:'admins',component:AdminlistComponent},
  {path:'updateAdmin/:adminId', component:UpdateadminComponent},
  {path:'detailsAdmin/:adminId',component:AdmindetailsComponent},
  {path:'vendorsignup',component:CreatevendorComponent},
  {path:'vendors',component:VendorlistComponent},
  {path:'updateVendor/:vendorId', component:UpdatevendorComponent},
  {path:'detailsVendor/:vendorId',component:VendordetailsComponent},
  {path:'login', component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
