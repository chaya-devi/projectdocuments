import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CreateuserComponent } from './createuser/createuser.component';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { UserlistComponent } from './userlist/userlist.component';
import { UpdateuserComponent } from './updateuser/updateuser.component';
import { UserService } from './user.service';
import { AdmindetailsComponent } from './admindetails/admindetails.component';
import { AdminlistComponent } from './adminlist/adminlist.component';
import { CreateadminComponent } from './createadmin/createadmin.component';
import { UpdateadminComponent } from './updateadmin/updateadmin.component';
import { AdminService } from './admin.service';
import { CreatevendorComponent } from './createvendor/createvendor.component';
import { VendordetailsComponent } from './vendordetails/vendordetails.component';
import { VendorlistComponent } from './vendorlist/vendorlist.component';
import { UpdatevendorComponent } from './updatevendor/updatevendor.component';
import { VendorService } from './vendor.service';
import { CreatevehicleComponent } from './createvehicle/createvehicle.component';
import { VehiclelistComponent } from './vehiclelist/vehiclelist.component';
import { VehicledetailsComponent } from './vehicledetails/vehicledetails.component';
import { UpdatevehicleComponent } from './updatevehicle/updatevehicle.component';
import { LoginComponent } from './login/login.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CreateuserComponent,
    UserdetailsComponent,
    UserlistComponent,
    UpdateuserComponent,
    AdmindetailsComponent,
    AdminlistComponent,
    CreateadminComponent,
    UpdateadminComponent,
    CreatevendorComponent,
    VendordetailsComponent,
    VendorlistComponent,
    UpdatevendorComponent,
    CreatevehicleComponent,
    VehiclelistComponent,
    VehicledetailsComponent,
    UpdatevehicleComponent,
    LoginComponent
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule

  ],
  providers: [
    { provide: UserService },
  { provide: AdminService },
  { provide: VendorService }],
  bootstrap: [AppComponent]
})
export class AppModule { }
