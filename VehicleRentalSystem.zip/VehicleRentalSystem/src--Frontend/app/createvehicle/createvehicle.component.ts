import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Vehicle } from '../vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-createvehicle',
  templateUrl: './createvehicle.component.html',
  styleUrls: ['./createvehicle.component.css']
})
export class CreatevehicleComponent implements OnInit {
  vehicle: Vehicle = new Vehicle();
  submitted = false;

  constructor(private vehicleService: VehicleService, private router: Router) { }

  ngOnInit(): void {
  }
    newVehicle(): void {
      this.submitted = false;
      this.vehicle = new Vehicle();
    }
  
    save() {
      this.vehicleService.createVehicle(this.vehicle).subscribe(data => {
        console.log(data+" "+this.vehicle)
       this.vehicle = new Vehicle();
        this.gotoList();
      },
     error => console.log(error));
    }
  
    onSubmit() {
      this.submitted = true;
      this.save();    
    }
  
    gotoList() {
      this.router.navigate(['/vehicles']);
    }
  
  
  

}
