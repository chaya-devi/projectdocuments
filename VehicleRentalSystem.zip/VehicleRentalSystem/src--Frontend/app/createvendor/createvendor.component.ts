import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-createvendor',
  templateUrl: './createvendor.component.html',
  styleUrls: ['./createvendor.component.css']
})
export class CreatevendorComponent implements OnInit {
  vendor: Vendor = new Vendor();
  submitted = false;



  constructor(private vendorService: VendorService, private router: Router) { }

  ngOnInit(): void {
  }
  newVendor(): void {
    this.submitted = false;
    this.vendor = new Vendor();

}
save() {
  this.vendorService.createVendor(this.vendor).subscribe(data => {
    console.log(data+" "+this.vendor)
   this.vendor = new Vendor();
    this.gotoList();
  },
 error => console.log(error));
}

onSubmit() {
  this.submitted = true;
  this.save();    
}

gotoList() {
  this.router.navigate(['/vendors']);
}
}

