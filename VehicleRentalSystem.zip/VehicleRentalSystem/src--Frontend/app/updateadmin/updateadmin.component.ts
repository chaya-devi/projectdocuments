import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-updateadmin',
  templateUrl: './updateadmin.component.html',
  styleUrls: ['./updateadmin.component.css']
})
export class UpdateadminComponent implements OnInit {
  adminId: number=0;
  admin: Admin=new Admin();

  constructor(private route: ActivatedRoute,private router: Router,
    private adminService: AdminService) { }

  ngOnInit(): void {
    this.admin = new Admin();

    this.adminId = this.route.snapshot.params['id'];
    
    this.adminService.getAdmin(this.adminId)
      .subscribe(data => {
        console.log(data)
        this.admin = data;
      }, error => console.log(error));
  }

  updateAdmin() {
    this.adminService.updateAdmin(this.adminId, this.admin)
      .subscribe(data => {
        console.log(data);
        this.admin = new Admin();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateAdmin();    
  }

  gotoList() {
    this.router.navigate(['/admins']);
  }

  

}
