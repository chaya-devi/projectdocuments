import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Vehicle } from '../vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-updatevehicle',
  templateUrl: './updatevehicle.component.html',
  styleUrls: ['./updatevehicle.component.css']
})
export class UpdatevehicleComponent implements OnInit {
  vehicleId: number=0;
  vehicle:Vehicle=new Vehicle();

  constructor(private route: ActivatedRoute,private router: Router,
    private vehicleService: VehicleService) { }

  ngOnInit(): void {
    this.vehicle = new Vehicle();

    this.vehicleId = this.route.snapshot.params['vehicleId'];
    
    this.vehicleService.getVehicle(this.vehicleId)
      .subscribe(data => {
        console.log(data)
        this.vehicle = data;
      }, error => console.log(error));
  }

  updateVehicle() {
    this.vehicleService.updateVehicle(this.vehicleId, this.vehicle)
      .subscribe(data => {
        console.log(data);
        this.vehicle = new Vehicle();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateVehicle();    
  }

  gotoList() {
    this.router.navigate(['/vehicles']);
  }

  

}
