import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-updatevendor',
  templateUrl: './updatevendor.component.html',
  styleUrls: ['./updatevendor.component.css']
})
export class UpdatevendorComponent implements OnInit {
  vendorId: number=0;
  vendor: Vendor=new Vendor();

  constructor(private route: ActivatedRoute,private router: Router,
    private vendorService: VendorService) { }

  ngOnInit(): void {
    this.vendor = new Vendor();

    this.vendorId = this.route.snapshot.params['vendorId'];
    
    this.vendorService.getVendor(this.vendorId)
      .subscribe(data => {
        console.log(data)
        this.vendor = data;
      }, error => console.log(error));
  }

  updateVendor() {
    this.vendorService.updateVendor(this.vendorId, this.vendor)
      .subscribe(data => {
        console.log(data);
        this.vendor = new Vendor();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateVendor();    
  }

  gotoList() {
    this.router.navigate(['/vendors']);
  }

  

}
