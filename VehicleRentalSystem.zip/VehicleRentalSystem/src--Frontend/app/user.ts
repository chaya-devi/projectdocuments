export class User{
    userId:number=0;
    userName:string="";
    password:string="";
    email:string="";
    contact:number=0;
    address:string="";
    adharId:string="";
    drivingLicense:string="";

    
}