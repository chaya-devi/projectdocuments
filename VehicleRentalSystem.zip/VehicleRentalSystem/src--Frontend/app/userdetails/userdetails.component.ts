import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import {User} from '../user';


@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
userId:number=0;
user: User=new User();

  constructor(private route:ActivatedRoute, private router:Router, private userService: UserService) { }

  ngOnInit():void{
    this.user = new User();

    this.userId=this.route.snapshot.params['userId'];
    this.userService.getUser(this.userId)
    .subscribe(data => {
      console.log(data)
      this.user=data;
    },error =>console.log(error));
    
    }
    list(){
      this.router.navigate([''])
    }
    


  

}
