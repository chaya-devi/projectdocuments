import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {
  users: Observable<User[]>=new Observable;

  constructor(private userService: UserService,private router: Router) { }

  ngOnInit(): void {
    this.getUsers();
  }
  getUsers()
  {
    this.users=this.userService.getUsers();
  }
  
  deleteUser(userId: number) {
    this.userService.deleteUser(userId)
      .subscribe(
        data => {
          console.log(data);
          this.getUsers();
        },
        error => console.log(error));
  }

  userDetails(userId: number){
    this.router.navigate(['details', userId]);
  }
  updateUser(userId: number)
  {
    this.router.navigate(['update', userId]);
  }


}
