import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  private baseUrl = 'http://localhost:9080/api/v2';

  constructor(private http: HttpClient) { }
  getVehicles(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllVehicles');
  }
  getVehicle(vehicleId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getVehicle/${vehicleId}`);
  }

  createVehicle(vehicle: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveVehicle', vehicle);
  }

  updateVehicle(vehicleId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateVehicle/${vehicleId}`, value);
  }

  deleteVehicle(vehicleId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteVehicle/${vehicleId}`, { responseType: 'text' });
  }

}
