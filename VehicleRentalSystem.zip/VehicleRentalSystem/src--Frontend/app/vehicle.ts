export class Vehicle{
    vehicleId:string="";
    modelName:string="";
    modelYear:number=0;
    brandName:string="";
    dailyPrice:number=0;
    vehiclePlateNo:string="";
    noOfSeats:number=0;
    availability:string="";
    vendorId:number=0;
}