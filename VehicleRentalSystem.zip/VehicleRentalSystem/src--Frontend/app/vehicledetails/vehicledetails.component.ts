import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Vehicle } from '../vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-vehicledetails',
  templateUrl: './vehicledetails.component.html',
  styleUrls: ['./vehicledetails.component.css']
})
export class VehicledetailsComponent implements OnInit {
  vehicleId: number=0;
  vehicle: Vehicle=new Vehicle();

  constructor(private route: ActivatedRoute,private router: Router,private vehicleService: VehicleService) { }

  ngOnInit(): void {
    this.vehicle = new Vehicle();

    this.vehicleId = this.route.snapshot.params['vehicleId'];
    
    this.vehicleService.getVehicle(this.vehicleId)
      .subscribe(data => {
        console.log(data)
        this.vehicle = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['vehicles']);
  }

  

}
