import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Vehicle } from '../vehicle';
import { VehicleService } from '../vehicle.service';

@Component({
  selector: 'app-vehiclelist',
  templateUrl: './vehiclelist.component.html',
  styleUrls: ['./vehiclelist.component.css']
})
export class VehiclelistComponent implements OnInit {
  vehicles: Observable<Vehicle[]>=new Observable;

  constructor(private vehicleService: VehicleService,private router: Router) { }

  ngOnInit(): void {
    this.getVehicles();

  }
  getVehicles()
  {
    this.vehicles=this.vehicleService.getVehicles();
  }
  
  deleteVehicle(vehicleId: number) {
    this.vehicleService.deleteVehicle(vehicleId)
      .subscribe(
        data => {
          console.log(data);
          this.getVehicles();
        },
        error => console.log(error));
  }

  vehicleDetails(vehicleId: number){
    this.router.navigate(['details', vehicleId]);
  }
  updateVehicle(vehicleId: number)
  {
    this.router.navigate(['update', vehicleId]);
  }


}
