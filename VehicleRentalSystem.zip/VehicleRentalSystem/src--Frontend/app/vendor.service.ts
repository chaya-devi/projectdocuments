import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VendorService {
  private baseUrl = 'http://localhost:9080/api/v2';

  constructor(private http: HttpClient) { }
  getVendors(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllVendors');
  }
  getVendor(vendorId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getVendor/${vendorId}`);
  }

  createVendor(vendor: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveVendor', vendor);
  }

  updateVendor(vendorId: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateVendor/${vendorId}`, value);
  }

  deleteVendor(vendorId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteVendor/${vendorId}`, { responseType: 'text' });
  }

}
