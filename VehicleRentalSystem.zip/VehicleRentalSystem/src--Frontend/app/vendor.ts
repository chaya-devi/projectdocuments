export class Vendor{
    vendorId:number=0;
    vendorName:string="";
    password:string="";
    email:string="";
    contact:number=0;
    address:string="";
    license:string="";
}