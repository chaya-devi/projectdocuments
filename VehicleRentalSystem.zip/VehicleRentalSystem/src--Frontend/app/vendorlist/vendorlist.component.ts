import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendorlist',
  templateUrl: './vendorlist.component.html',
  styleUrls: ['./vendorlist.component.css']
})
export class VendorlistComponent implements OnInit {
  vendors: Observable<Vendor[]>=new Observable;

  constructor(private vendorService: VendorService,private router: Router) { }

  ngOnInit(): void {
    this.getVendors();

  }
  getVendors()
  {
    this.vendors=this.vendorService.getVendors();
  }
  
  deleteVendor(vendorId: number) {
    this.vendorService.deleteVendor(vendorId)
      .subscribe(
        data => {
          console.log(data);
          this.getVendors();
        },
        error => console.log(error));
  }

  vendorDetails(vendorId: number){
    this.router.navigate(['details', vendorId]);
  }
  updateVendor(vendorId: number)
  {
    this.router.navigate(['update', vendorId]);
  }


}
