import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreatePgownerComponent } from './create-pgowner/create-pgowner.component';
import { HomeComponent } from './home/home.component';
import { PgownerDetailsComponent } from './pgowner-details/pgowner-details.component';
import { PgownerListComponent } from './pgowner-list/pgowner-list.component';
import { UpdatePgownerComponent } from './update-pgowner/update-pgowner.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserListComponent } from './user-list/user-list.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { CreateBookingComponent } from './create-booking/create-booking.component';
import { BookingDetailsComponent } from './booking-details/booking-details.component';


const routes: Routes =[
  {path:'',component:HomeComponent},
  
  {path: '',redirectTo: 'admins', pathMatch: 'full'},
  { path: 'pgowners', component: PgownerListComponent},
  { path: 'add', component:CreatePgownerComponent},
  { path: 'update/:id', component:UpdatePgownerComponent},
  { path: 'details/:id', component:PgownerDetailsComponent},
  {path:'about',component:AboutComponent},
  {path: 'login', component:LoginComponent},
  { path: 'users', component: UserListComponent },
  { path: 'update/:id', component: UpdateUserComponent },
  { path: 'details/:id', component:UserDetailsComponent },
  {path:'booking',component:BookingListComponent},
  {path:'addbooking',component:CreateBookingComponent},
  {path:'bookingdetails',component:BookingDetailsComponent},
  {path:'pgowner-list',component:PgownerListComponent},
  
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
