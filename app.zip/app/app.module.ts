import { Injectable, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CreatePgownerComponent } from './create-pgowner/create-pgowner.component';
import { PgownerDetailsComponent } from './pgowner-details/pgowner-details.component';
import { PgownerListComponent } from './pgowner-list/pgowner-list.component';
import { UpdatePgownerComponent } from './update-pgowner/update-pgowner.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { LoginComponent } from './login/login.component';
import { UpdateUserComponent } from './update-user/update-user.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserListComponent } from './user-list/user-list.component';
import { BookingDetailsComponent } from './booking-details/booking-details.component';
import { BookingListComponent } from './booking-list/booking-list.component';
import { CreateBookingComponent } from './create-booking/create-booking.component';
import { AdminService } from './services/admin.service';

import { RegisterService } from './services/register.service';

import { UserService } from './user.service';

 

@NgModule({
  declarations: [
    AppComponent,
    CreatePgownerComponent,
    PgownerDetailsComponent,
    PgownerListComponent,
    UpdatePgownerComponent,
    HomeComponent,
    AboutComponent,
    LoginComponent,
    UpdateUserComponent,
    UserDetailsComponent,
    UserListComponent,
    BookingDetailsComponent,
    BookingListComponent,
    CreateBookingComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule
  ],
  providers: [AdminService,RegisterService,
    
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
