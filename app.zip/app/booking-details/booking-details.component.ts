
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking-details',
  templateUrl: './booking-details.component.html',
  styleUrls: ['./booking-details.component.css']
})
export class BookingDetailsComponent implements OnInit {

  
    userid:number=0;
    booking:Booking=new Booking();
     constructor(private route:ActivatedRoute,private router:Router,private bookingService:BookingService) { }
   
     ngOnInit(): void {
       this.booking=new Booking();
       this.userid=this.route.snapshot.params['userid'];
       this.bookingService.getBooking(this.userid)
       .subscribe(data => {
         console.log(data)
         this.booking = data;
       }, error => console.log(error));
       //this.list();
   }
   
   list(){
     this.router.navigate(['bookings']);
   }
   }
   
     
   
   