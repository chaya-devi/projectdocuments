import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Booking } from '../booking';
import { BookingService } from '../booking.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrls: ['./booking-list.component.css']
})
export class BookingListComponent implements OnInit {
  bookings: Observable<Booking[]>= new Observable;
  constructor(private bookingService:BookingService,private router:Router){}

  

  ngOnInit(): void {
    this.getBookings();
  }

getBookings()
{
  this.bookings=this.bookingService.getBookings();
}

deleteBooking(userid: number) {
  this.bookingService.deleteBooking(userid)
    .subscribe(
      data => {
        console.log(data);
        this.getBookings();
      },
      error => console.log(error));
}

bookingDetails(userid: number){
  this.router.navigate(['details', userid]);
}
updateBooking(userid: number)
{
  this.router.navigate(['update', userid]);
}
}