
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BookingService {
 
 
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getBookings(): Observable<any> {
    //console.log(this.http.get(`${this.baseUrl}`+'/getBookings'));
    return this.http.get(`${this.baseUrl}`+'/getAllBooking');
  }
  getBooking(userid: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getBooking/${userid}`);
  }

  createBooking(booking: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveBooking', booking);
  }

  updateBooking(userid: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateBooking/${userid}`, value);
  }

  deleteBooking(userid: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteBooking/${userid}`, { responseType: 'text' });
  }


}


