export class Booking{
    userid:number=0;
    bookingnumber:number=0;
    movein:string="";
    moveout:string=" ";
    bookingstatus:string=" ";
    pgid:number=0

}