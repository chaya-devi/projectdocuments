import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePgownerComponent } from './create-pgowner.component';

describe('CreatePgownerComponent', () => {
  let component: CreatePgownerComponent;
  let fixture: ComponentFixture<CreatePgownerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatePgownerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePgownerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
