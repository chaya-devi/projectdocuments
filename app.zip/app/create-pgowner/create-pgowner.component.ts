import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PgOwner } from '../pgowner';
import { PgownerService } from '../pgowner.service';

@Component({
  selector: 'app-create-pgowner',
  templateUrl: './create-pgowner.component.html',
  styleUrls: ['./create-pgowner.component.css']
})
export class CreatePgownerComponent implements OnInit {

 pgowner:  PgOwner=new (PgOwner);
 submitted = false;
 
  constructor(private pgownerService: PgownerService, private router: Router) { }

  ngOnInit(): void {
  }

  newPgowner(): void{
    this.submitted = false;
    this.pgowner = new PgOwner();
  }

  save(){
    this.pgownerService.CreatePgOwner(this.pgowner).subscribe(data => {
      console.log(data+" "+this.pgowner)
      this.pgowner = new PgOwner();
      this.gotoList();
    },
    error => console.log(error));
    
  }

  onSubmit(){
    this.submitted = true;
    this.save();
  }

  gotoList(){
    this.router.navigate(['/pgowner']);
  }

  
}
