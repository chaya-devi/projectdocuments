import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AdminService } from '../services/admin.service';
import { NgForm } from '@angular/forms';
import { Admin } from '../model/admin.model';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  admin: Admin = new Admin();
  message!: string;
  submitted: boolean | undefined;
 
  constructor(private adminService: AdminService, private router: Router) { }
  ngOnInit(): void {
    
  }

  onSubmit() {
    this.submitted = true;
    this.validate();    
  }

  validate() {
   // alert(this.user.username);
    this.adminService.validateAdmin(this.admin).subscribe(data => {
   
    console.log(data+" "+this.admin)
    if(data!=null)
    {
      alert('in if');
    this.router.navigate(['/pgowners']);
    //sessionStorage.setItem("userid", this.admin.userid);
    sessionStorage.setItem("login","success");
    //this.hasLoginFailed=false;
    }
    else
    {
      alert('in else');
    this.router.navigate(['/login']);
    this.message="Invalid Credentials....Try again!";
    //this.hasLoginFailed=true;
    sessionStorage.setItem("login","failed");
    this.admin = new Admin();
    }
    },
   error => console.log(error)
   
   );
  }

 
}
