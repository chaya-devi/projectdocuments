export class Admin{
    userid:number=0;
    password:string=" ";
}