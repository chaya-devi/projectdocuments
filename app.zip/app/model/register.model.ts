export class Register{
    userid:number=0;
    username:string=" ";
    email:string=" ";
    password:string=" ";
    gender:String=" ";
    phonenumber:number=0;
}