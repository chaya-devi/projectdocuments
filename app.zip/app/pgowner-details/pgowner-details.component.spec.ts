import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PgownerDetailsComponent } from './pgowner-details.component';

describe('PgownerDetailsComponent', () => {
  let component: PgownerDetailsComponent;
  let fixture: ComponentFixture<PgownerDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PgownerDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PgownerDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
