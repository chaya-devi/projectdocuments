import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PgOwner} from '../pgowner';
import { PgownerService } from '../pgowner.service';


@Component({
  selector: 'app-pgowner-details',
  templateUrl: './pgowner-details.component.html',
  styleUrls: ['./pgowner-details.component.css']
})
export class PgownerDetailsComponent implements OnInit {

  id: number=0;
  pgowner: PgOwner=new PgOwner();

  constructor(private route:ActivatedRoute,private router:Router,private pgownerService: PgownerService) { }

  ngOnInit() {
    this.pgowner = new PgOwner();

    this.id = this.route.snapshot.params['id'];

    this.pgownerService.getPgOwner(this.id)
    .subscribe((data: PgOwner) => {
      console.log(data)
      this.pgowner = data;
    },
       (     error:any) =>console.log(error));
    
    }
    list(){
      this.router.navigate(['pgowners']);
  }

}
