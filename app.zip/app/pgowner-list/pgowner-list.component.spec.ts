import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PgownerListComponent } from './pgowner-list.component';

describe('PgownerListComponent', () => {
  let component: PgownerListComponent;
  let fixture: ComponentFixture<PgownerListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PgownerListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PgownerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
