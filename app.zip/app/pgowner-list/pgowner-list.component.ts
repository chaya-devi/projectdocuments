import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PgOwner } from '../pgowner';
import { PgownerService } from '../pgowner.service';

@Component({
  selector: 'app-pgowner-list',
  templateUrl: './pgowner-list.component.html',
  styleUrls: ['./pgowner-list.component.css']
})
export class PgownerListComponent implements OnInit {
  pgowners: Observable<PgOwner[]>=new Observable;

  constructor(private pgownerService: PgownerService,private router: Router) { }

  ngOnInit(): void {
    this.getPgOwner();
  }

  getPgOwner()
  {
    this.pgowners=this.pgownerService.getPgOwners();
  }
  deletePgOwner(id: number)
  {
    this.pgownerService.deletePgOwner(id)
    .subscribe(
      data => {
        console.log(data);
        this.getPgOwner();
      },
    error => console.log(error));
  }

  pgownerDetails(id:number){
    this.router.navigate(['details', id]);
  }
  updatePgOwner(id:number)
  {
    this.router.navigate(['update', id]);
  }
}
