import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PgOwner } from './pgowner';

@Injectable({
  providedIn: 'root'
})
export class PgownerService {

  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getPgOwners(): Observable<any>{
    console.log(this.http.get(`${this.baseUrl}`+'/getAllPgOwners'));
    return this.http.get(`${this.baseUrl}`+'/getAllPgOwners');
  }
  getPgOwner(pgid: number): Observable<any>{
    return this.http.get(`${this.baseUrl}/getPgOwner/${pgid}`);
  }
  CreatePgOwner(pgowner: object):Observable<object> {
    return this.http.post(`${this.baseUrl}`+'/savePgOwner', pgowner);
  }
  updatePgOwner(pgid: number,value: any): Observable<object>{
  return this.http.put(`${this.baseUrl}/updatePgOwner/${pgid}`,value)
}
deletePgOwner(pgid: number): Observable<any>{
  return this.http.delete(`${this.baseUrl}/deletePgOwner/${pgid}`,{ responseType: 'text'});
}
}
