export class PgOwner{
    id:number=0;
    pgName:string="";
    typeofpg:string="";
    rentpermonth:number=0;
    noofrooms:number=0;
    noofsharing:number=0;
    address:string="";
    location:string="";
    status:string="";
}