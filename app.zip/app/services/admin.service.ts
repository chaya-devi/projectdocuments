import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from '../model/admin.model';



@Injectable()

  export class AdminService {
  
    constructor(private http:HttpClient) { }
  
  
    public validateAdmin(admin:Admin ):Observable<any> {
      return this.http.post("http://localhost:8080/api/v1/loginAdmin",admin)
    }
  
  }