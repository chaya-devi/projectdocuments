
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from '../model/register.model';



@Injectable({
  providedIn: 'root'
})
export class RegisterService {
  validateAdmin: any;
  RegisterFromRemote(a: any) {
    throw new Error('Method not implemented.');
  }

  constructor(private _http:HttpClient) { }


  public registerFromRemote(register:Register ):Observable<any> {
    return this._http.post<any>("http://localhost:8080/api/v1/saveUser", register)
  }

}
