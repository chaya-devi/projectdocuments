import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatePgownerComponent } from './update-pgowner.component';

describe('UpdatePgownerComponent', () => {
  let component: UpdatePgownerComponent;
  let fixture: ComponentFixture<UpdatePgownerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatePgownerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatePgownerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
