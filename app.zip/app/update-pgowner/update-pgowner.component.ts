import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PgOwner } from '../pgowner';
import { PgownerService } from '../pgowner.service';

@Component({
  selector: 'app-update-pgowner',
  templateUrl: './update-pgowner.component.html',
  styleUrls: ['./update-pgowner.component.css']
})
export class UpdatePgownerComponent implements OnInit {
  id: number=0;
  pgowner : PgOwner=new PgOwner();

  constructor(private route: ActivatedRoute,private router: Router,
    private pgownerService: PgownerService) { }

  ngOnInit(){
    this.pgowner=new PgOwner();

    this.id=this.route.snapshot.params['id'];

    this.pgownerService.getPgOwner(this.id)
    .subscribe(data => {
        console.log(data)
        this.pgowner=data;
       },
       error => console.log(error));
  }

  updatePgOwner(){
    this.pgownerService.updatePgOwner(this.id,this.pgowner)
    .subscribe(data =>
      {
        console.log(data);
        this.pgowner = new PgOwner();
        this.gotoList();
      },
      error => console.log(error));
  }
  onsubmit(){
    this.updatePgOwner();
  }

  onSubmit(){
    this.updatePgOwner();
  }
  gotoList(){
    this.router.navigate(['/pgowners'])
  }

}
