import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})

//component-->service-->http request

export class UserListComponent implements OnInit {
  employees: Observable<User[]>=new Observable;
  users!: Observable<any>;

  constructor(private userService: UserService,private router: Router) {}
  
  ngOnInit(): void {
    this.getUsers();
  }

  getUsers()
  {
    this.users=this.userService.getUsers();
  }
  
  deleteUser(id: number) {
    this.userService.deleteUser(id)
      .subscribe(
        data => {
          console.log(data);
          this.getUsers();
        },
        error => console.log(error));
  }

  userDetails(id: number){
    this.router.navigate(['details', id]);
  }
  updateUser(id: number)
  {
    this.router.navigate(['update', id]);
  }
}