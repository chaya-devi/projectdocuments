import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  register: any;
  validateUser(user: User) {
    throw new Error('Method not implemented.');
  }

  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getUsers(): Observable<any>{
    console.log(this.http.get(`${this.baseUrl}`+'/getAllUsers'));
    return this.http.get(`${this.baseUrl}`+'/getAllUsers');
  }
  getUser(userid: number): Observable<any>{
    return this.http.get(`${this.baseUrl}/getUser/${userid}`);
  }
  CreateUser(user: object):Observable<object> {
    return this.http.post(`${this.baseUrl}`+'/saveUser', user);
  }
  updateUser(userid: number,value: any): Observable<object>{
  return this.http.put(`${this.baseUrl}/updatePgOwner/${userid}`,value)
}
deleteUser(userid: number): Observable<any>{
  return this.http.delete(`${this.baseUrl}/deletePgOwner/${userid}`,{ responseType: 'text'});
}
}

