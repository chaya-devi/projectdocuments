export class User{
    userid:number=0;
    email:string="";
    gender:string="";
    password:number=0;
    username:string="";
  
    
   
  
}