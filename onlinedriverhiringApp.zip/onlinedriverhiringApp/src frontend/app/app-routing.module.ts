import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HireComponent } from './hire/hire.component';
import { HomeComponent } from './home/home.component';
import { LogoutComponent } from './logout/logout.component';
import { MyridesComponent } from './myrides/myrides.component';
import { TransactionsComponent } from './transactions/transactions.component';

const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'myrides',component:MyridesComponent},
  {path:'transactions',component:TransactionsComponent},
  {path:'hire',component:HireComponent},
  {path:'logout',component:LogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
