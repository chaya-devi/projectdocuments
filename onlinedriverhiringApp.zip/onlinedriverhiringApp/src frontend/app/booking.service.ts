import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyrideService {
 
 
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getBookings(): Observable<any> {
    //console.log(this.http.get(`${this.baseUrl}`+'/getBookings'));
    return this.http.get(`${this.baseUrl}`+'/getAllBooking');
  }
  getMyRide(DriverAadhaar_id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getBooking/${DriverAadhaar_id}`);
  }

  createMyRide(booking: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveBooking', booking);
  }

  updateMyRide(DriverAadhaar_id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateMyRide/${DriverAadhaar_id}`, value);
  }

  deleteMyRide(DriverAadhaar_id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteMyRide/${DriverAadhaar_id}`, { responseType: 'text' });
  }


}
