export class MyRide{
    DriverAadhaarid:number=0;
    Vehicle_Type:String=" ";
    Vehicle_no:number=0;
    Place:string=" ";
    Available_date:string=" ";


}