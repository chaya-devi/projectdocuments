export class Transactions{
   
   transactionId:number=0;
    Vehicle_no:number=0;
   amount:number=0;
    driverAadhaar:number=0;
    userAadhaar:number=0


}