import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Transactions } from '../transaction'
import { TransactionsService } from '../transaction.service'
@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {

  transactions: Observable<Transactions[]>=new Observable;
  TransactionService: any;

  constructor(private reservationsService: TransactionsService,private router: Router) {}
  
  ngOnInit(): void {
    this.getTransaction();
  }

  getTransaction()
  {
    this.transactions=this.TransactionsService.getTransaction();
  }

  TransactionDetails(id: number){
    this.router.navigate(['details', id]);
  }
}

