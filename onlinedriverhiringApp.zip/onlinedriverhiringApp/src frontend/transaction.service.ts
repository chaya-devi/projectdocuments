import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {
 
 
  private baseUrl = 'http://localhost:8080/api/v1';

  constructor(private http: HttpClient) { }

  getTransaction(): Observable<any> {
    
    return this.http.get(`${this.baseUrl}`+'/getAllTransactions');
  }
  getTransaction(DriverAadhaar_id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getTransaction/${DriverAadhaar_id}`);
  }

  createTransaction(booking: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveTransaction', transactions);
  }

  updateTransaction(DriverAadhaar_id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateTransactions/${DriverAadhaar_id}`, value);
  }

  deleteTransaction(DriverAadhaar_id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteTransactions/${DriverAadhaar_id}`, { responseType: 'text' });
  }


}
