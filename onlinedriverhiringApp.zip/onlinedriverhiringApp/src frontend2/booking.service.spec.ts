import { TestBed } from '@angular/core/testing';
import { MyridedetailsComponent } from './myridedetails/myridedetails.component';
import { MyrideService } from './booking.service';

describe('MyrideService', () => {
  let service: MyrideService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyrideService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
