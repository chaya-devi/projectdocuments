import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyRide } from '../booking';
import { MyrideService } from '../booking.service';

@Component({
  selector: 'app-createride',
  templateUrl: './createride.component.html',
  styleUrls: ['./createride.component.css']
})
export class CreaterideComponent implements OnInit {
booking:MyRide=new MyRide();
submitted = false;
constructor(private bookingService:MyrideService,private router:Router) { }

ngOnInit(): void {
}
newMyRide():void{
  this.submitted=false;
  this.booking=new MyRide();

}




save() {
this.bookingService.createMyRide(this.booking).subscribe(data => {
  console.log(data+ "" +this.booking)
 this.booking = new MyRide();
  this.gotoList();
},
  error => console.log(error));
}

onSubmit() {
this.submitted = true;
this.save();    
}

gotoList() {
this.router.navigate(['/bookings']);
}
}
