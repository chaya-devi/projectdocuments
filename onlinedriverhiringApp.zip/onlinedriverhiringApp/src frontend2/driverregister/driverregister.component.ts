import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormControlDirective, FormGroup, Validators } from '@angular/forms';
import { UrlSerializer } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { Users, UsersService } from './users.service';

@Component({
  selector: 'app-driverregister',
  templateUrl: './driverregister.component.html',
  styleUrls: ['./driverregister.component.css']
})
export class DriverregisterComponent implements OnInit {

  regForm!:FormGroup

  observableSubscription!: Subscription;
  constructor(private ngbActiveModal: NgbActiveModal,private formBuilder:FormBuilder,private usersService:UsersService) {
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(){
    this.regForm=this.formBuilder.group({
      DriverAadhaar_id:["",Validators.compose([Validators.required,Validators.maxLength(12)])],
      first_name:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      last_name:["",Validators.compose([Validators.required,Validators.maxLength(25)])],
      Gender:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      email:["",Validators.compose([Validators.required,Validators.maxLength(25)])],
      phone_number:["",Validators.compose([Validators.required,Validators.maxLength(10)])],
      License_no:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      Vehicle_Type:["",Validators.compose([Validators.required,Validators.maxLength(25)])],
      Vehicle_no:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      Place:["",Validators.compose([Validators.required,Validators.maxLength(30)])],
      hired_date:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      Available_date:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
    })
  }
submit(){
  let user=new Users();
  user.DriverAadhaar_id=this.regForm.controls["DriverAadhaar_id"].value;
  user.firstName=this.regForm.controls["first_name"].value;
  user.lastName=this.regForm.controls["last_name"].value;
  user.Gender=this.regForm.controls["Gender"].value;
  user.emailId=this.regForm.controls["email"].value;
  user.phonenumber=this.regForm.controls["phone_number"].value;
  user.License_no=this.regForm.controls["License_no"].value;
  user.Vehicle_Type=this.regForm.controls["Vehile_Type"].value;
  user.Vehicle_no=this.regForm.controls["Vehicle_no"].value;
  user.Place=this.regForm.controls["Place"].value;
  user.hire_date=this.regForm.controls["hire_date"].value;
  user.Available_date=this.regForm.controls["Available_date"].value;
  this.observableSubscription=this.usersService.saveUsers(user).subscribe(data=>{
    console.log("successful");
    this.close();
  },error=>{
    console.log(error);
  });
}
close(){
this.ngbActiveModal.close();
}
ngOnDestroy() {
  if (this.observableSubscription)
    this.observableSubscription.unsubscribe();
}
}
