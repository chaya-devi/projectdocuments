import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export class Users{
  public DriverAadhaar_id!:number;
  public firstName!:string;
  public lastName!:string;
  public Gender!:string;
  public emailId!:string;
  public phonenumber!:number ;
  public Address!:string;
  public License_no!: number;
  public Vehicle_Type!: string;
  public Vehicle_no!: number;
  public Place!: string;
  public hire_date!: string;
  public Available_date!: string;
}
@Injectable({
  providedIn: 'root'
})
export class UsersService {

  apiUrl: string;
  constructor(private httpClient: HttpClient) {
    this.apiUrl = "http://localhost:8080/api/v1";
  }

  saveUsers(user: Users): Observable<Users> {
    return this.httpClient.post<Users>(this.apiUrl + "/saveUsers" , user);
  }

  
}