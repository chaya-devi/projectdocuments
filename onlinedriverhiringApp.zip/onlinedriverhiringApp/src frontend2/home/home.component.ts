import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DriverregisterComponent } from '../driverregister/driverregister.component';
import { RegistrationComponent } from '../registration/registration.component';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private ngbModal:NgbModal) { }

  ngOnInit(): void {
  }
  openDriverregisterForm(){
    this.ngbModal.open(DriverregisterComponent,{backdrop:false});
  }
  openRegistrationForm(){
    this.ngbModal.open(RegistrationComponent,{backdrop:false});
  }
  
}


