import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyridedetailsComponent } from './myridedetails.component';

describe('MyridedetailsComponent', () => {
  let component: MyridedetailsComponent;
  let fixture: ComponentFixture<MyridedetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyridedetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyridedetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
