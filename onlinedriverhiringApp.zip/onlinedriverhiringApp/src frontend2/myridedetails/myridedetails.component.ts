import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MyRide } from '../booking';
import { MyrideService } from '../booking.service';

@Component({
  selector: 'app-myridedetails',
  templateUrl: './myridedetails.component.html',
  styleUrls: ['./myridedetails.component.css']
})
export class MyridedetailsComponent implements OnInit {

  DriverAadhaarid:number=0;
  booking:MyRide=new MyRide();
   constructor(private route:ActivatedRoute,private router:Router,private bookingService:MyrideService) { }
 
   ngOnInit(): void {
     this.booking=new MyRide();
     this.DriverAadhaarid=this.route.snapshot.params['DriverAadhaarid'];
     this.bookingService.getMyRide(this.DriverAadhaarid)
     .subscribe((data: any) => {
       console.log(data)
       this.booking = data;
     }, (error: any) => console.log(error));
     //this.list();
 }
 
 list(){
   this.router.navigate(['bookings']);
 }
 }
