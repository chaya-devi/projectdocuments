import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { MyRide } from '../booking';
import { MyrideService } from '../booking.service';

@Component({
  selector: 'app-myrides',
  templateUrl: './myrides.component.html',
  styleUrls: ['./myrides.component.css']
})
export class MyridesComponent implements OnInit {

  bookings: Observable<MyRide[]>= new Observable;
  constructor(private bookingService:MyrideService,private router:Router){}

  

  ngOnInit(): void {
    this.getBookings();
  }

getBookings()
{
  this.bookings=this.bookingService.getBookings();
}

deleteMyRide(DriverAadhaarid: number) {
  this.bookingService.deleteMyRide(DriverAadhaarid)
    .subscribe(
      (      data: any) => {
        console.log(data);
        this.getBookings();
      },
      (      error: any) => console.log(error));
}

bookingDetails(DriverAadhaarid: number){
  this.router.navigate(['details', DriverAadhaarid]);
}
updateMyRide(DriverAadhaarid: number)
{
  this.router.navigate(['update', DriverAadhaarid]);
}
}