import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormControlDirective, FormGroup, Validators } from '@angular/forms';
import { UrlSerializer } from '@angular/router';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { Users, UsersService } from './users.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  regForm!:FormGroup

  observableSubscription!: Subscription;
  constructor(private ngbActiveModal: NgbActiveModal,private formBuilder:FormBuilder,private usersService:UsersService) {
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(){
    this.regForm=this.formBuilder.group({
      UsersAadhaar_id:["",Validators.compose([Validators.required,Validators.maxLength(12)])],
      first_name:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      last_name:["",Validators.compose([Validators.required,Validators.maxLength(25)])],
      Gender:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
      email:["",Validators.compose([Validators.required,Validators.maxLength(25)])],
      phone_number:["",Validators.compose([Validators.required,Validators.maxLength(10)])],
      Address:["",Validators.compose([Validators.required,Validators.maxLength(20)])],
    })
  }
submit(){
  let user=new Users();
  user.id=this.regForm.controls["UsersAadhaar_id"].value;
  user.firstName=this.regForm.controls["first_name"].value;
  user.lastName=this.regForm.controls["last_name"].value;
  user.Gender=this.regForm.controls["Gender"].value;
  user.emailId=this.regForm.controls["email"].value;
  user.phonenumber=this.regForm.controls["phone_number"].value;
  user.Address=this.regForm.controls["Address"].value;
  this.observableSubscription=this.usersService.saveUsers(user).subscribe(data=>{
    console.log("successful");
    this.close();
  },error=>{
    console.log(error);
  });
}
close(){
this.ngbActiveModal.close();
}
ngOnDestroy() {
  if (this.observableSubscription)
    this.observableSubscription.unsubscribe();
}
}