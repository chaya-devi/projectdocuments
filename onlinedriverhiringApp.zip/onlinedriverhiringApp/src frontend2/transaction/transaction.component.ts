import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Transaction } from 'Transaction'
import { TransactionService } from 'Transaction.service'
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  transactions: Observable<Transaction[]>=new Observable;
  TransactionService: any;

  constructor(private reservationsService: TransactionService,private router: Router) {}
  
  ngOnInit(): void {
    this.getTransaction();
  }

  getTransaction()
  {
    this.transactions=this.TransactionService.getTransaction();
  }

  TransactionDetails(id: number){
    this.router.navigate(['details', id]);
  }
}
