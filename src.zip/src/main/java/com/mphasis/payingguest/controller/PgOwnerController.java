package com.mphasis.payingguest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.payingguest.exception.ResourceNotFoundException;
import com.mphasis.payingguest.model.PgOwner;
import com.mphasis.payingguest.service.PgOwnerService;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v1")
@RestController
public class PgOwnerController {

	@Autowired
	PgOwnerService pgService;

//http://localhost:8080/api/v1/getAllPgOwners
	@GetMapping("/getAllPgOwners")
	public List<PgOwner> getPgOwners() {
		List<PgOwner> pgList = pgService.fetchPgOwners();

		return pgList;

	}

	// http://localhost:8080/api/v1/getPayingGuest/1
	@GetMapping("/getPgOwner/{pgId}")
	public ResponseEntity<PgOwner> getPgOwnerById(@PathVariable("pgId") int pgId)
			throws ResourceNotFoundException {
		PgOwner pgowner = pgService.getPgOwner(pgId);
		return ResponseEntity.ok().body(pgowner);
	}

	// http://localhost:8080/api/v1/savePayingGuest
	@PostMapping("/savePgOwner")
	public PgOwner addPgOwner(@RequestBody PgOwner pgowner) {
		pgowner  = pgService.savePgOwner(pgowner);

		// return new ResponseEntity<>("PayingGuest added successsfully", HttpStatus.OK);
		return pgowner;
	}

	// http://localhost:8080/api/v1/updatePayingGuest/2
	@PutMapping("/updatePgOwner/{id}")
	public ResponseEntity<PgOwner> updatePgOwner(@PathVariable("id") int pgId,
			@RequestBody PgOwner pgownerDetails) throws ResourceNotFoundException {
		PgOwner pgowner = pgService.getPgOwner(pgId);

		pgowner.setpgName(pgownerDetails.getpgName());
		pgowner.settypeofpg(pgownerDetails.gettypeofpg());
		pgowner.setrentpermonth(pgownerDetails.getrentpermonth());
		pgowner.setnoofrooms(pgownerDetails.getnoofrooms());
		pgowner.setnoofsharing(pgownerDetails.getnoofsharing());
		pgowner.setaddress(pgownerDetails.getaddress());
		pgowner.setlocation(pgownerDetails.getlocation());
		pgowner.setstatus(pgownerDetails.getstatus());
		
		final PgOwner updatedPgOwner = pgService.savePgOwner(pgowner);
		return ResponseEntity.ok(updatedPgOwner);
	}

//http://localhost:8080/api/v1/deletePayingGuest/1
	@DeleteMapping(value = "/deletePgOwner/{pgId}")
	public ResponseEntity<Object> deletePgOwner(@PathVariable("pgId") int pgId) {

	    pgService.deletePgOwner(pgId);
		return new ResponseEntity<>("PgOwner deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deletePayingGuest/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int pgId) throws
	 * ResourceNotFoundException { // PayingGuest payingguest =
	 * pgService.getPayingGuest(pgId);
	 * 
	 * System.out.println("delete method called");
	 * pgService.deletePayingGuest(pgId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}


