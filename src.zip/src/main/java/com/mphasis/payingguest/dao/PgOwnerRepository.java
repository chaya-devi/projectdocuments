package com.mphasis.payingguest.dao;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.payingguest.model.PgOwner;

@Repository
public interface PgOwnerRepository extends JpaRepository<PgOwner ,Integer>  {

	//@Query("SELECT pg FROM Pgowners pg WHERE pg.status =?1") JPQL
	//Collection<Pgowners> findAllActivePgowners();
	
}
