package com.mphasis.payingguest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.mphasis.payingguest.model.User;
import com.mphasis.payingguest.model.UserLogin;

public interface UserLoginRepository extends JpaRepository<User, String>{
	@Query("SELECT ul FROM UserLogin ul WHERE ul.userid =?1 and ul.password=?2")
			public UserLogin validateUserLogin(int userid,String password);

	
	
	
}