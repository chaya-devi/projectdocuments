package com.mphasis.payingguest.model;



import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="booking")
public class Booking {

	@Id
	@Column(name="userid")
	
	private int userid;
	@Column(name="pgid")
	private int pgid;
	@Column(name="bookingnumber")
	private int bookingnumber;
	@Column(name="movein")
	@Temporal(TemporalType. DATE) 
	private Date movein;
	@Column(name="moveout")
	@Temporal(TemporalType. DATE) 
	private Date moveout;
	@Column(name="action")
	private String action;
	public Booking(int userid, int pgid, int bookingnumber, Date movein, Date moveout, String action) {
        super();
        
        this.userid = userid;
        this.pgid = pgid;
        this.bookingnumber =bookingnumber;
        this.movein=movein;
        this.moveout=moveout;
        this.action=action;
    }
	public Booking() {
		// TODO Auto-generated constructor stub
	}

	
	
	
	public int getuserid() {
		return userid;
	}
	public void setuserid(int userid) {
		this.userid = userid;
	}
	public int getpgid() {
		return pgid;
	}
	public void setpgid(int pgid) {
		this.pgid = pgid;
	}
	public int getbookingnumber() {
		return bookingnumber;
	}
	public void setbookingnumber(int bookingnumber) {
		this.bookingnumber = bookingnumber;
	}
	public Date getmovein() {
		return movein;
	}
	public void setmovein(Date movein) {
		this.movein = movein;
		
	}
	public Date getmoveout() {
		return moveout;
	}
	public void setmoveout(Date moveout) {
		this.moveout=moveout;
	}
	public String getaction() {
		return action;
	}
	public void setaction(String action) {
		this.action=action;
	}
	

}

