package com.mphasis.payingguest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pgowner")
public class PgOwner {
	@Id
	@GeneratedValue
	@Column(name="pgid")
	private int id;
	@Column(name="pgname")
	
	private String pgName;
	@Column(name="typeofpg")
	private String typeofpg;
	@Column(name="rentpermonth")
	private int rentpermonth;
	@Column(name="noofrooms")
	private int noofrooms;
	@Column(name="noofsharing")
	private int noofsharing;
	@Column(name="address")
	private String address;
	@Column(name="location")
	private String location;
	@Column(name="status")
	private String status;
	
	public PgOwner(String pgName, String typeofpg, int rentpermonth, int noofrooms,int noofsharing, String address,String location, String status) {
        super();
        this.pgName=pgName;
        this.typeofpg = typeofpg;
        this.rentpermonth= rentpermonth;
        this.noofrooms= noofrooms;
        this.noofsharing= noofsharing;
        this.address= address;
        this.location= location;
        this.status= status;
    }
	public PgOwner() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getpgName() {
		return pgName;
	}
	public void setpgName(String pgName) {
		this.pgName = pgName;
	}
	public String gettypeofpg() {
		return typeofpg;
	}
	public void settypeofpg(String typepfpg) {
		this.typeofpg = typeofpg;
	}
	public int getrentpermonth() {
		return rentpermonth;
	}
	public void setrentpermonth(int rentpermonth) {
		this.rentpermonth = rentpermonth;
	}
	public int getnoofrooms() {
		return noofrooms;
	}
	public void setnoofrooms(int noofrooms) {
		this.noofrooms = noofrooms;
	}
	public int getnoofsharing() {
		return noofsharing;
	}
	public void setnoofsharing(int noofsharing) {
		this.noofsharing = noofsharing;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public String getlocation() {
		return location;
	}
	public void setlocation(String location) {
		this.location = location;
	}
	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}



	

}