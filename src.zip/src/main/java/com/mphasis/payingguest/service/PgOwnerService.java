package com.mphasis.payingguest.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.payingguest.dao.PgOwnerRepository;
import com.mphasis.payingguest.model.PgOwner;

@Service
public class PgOwnerService {

	@Autowired
	PgOwnerRepository pgOwnerRepository;
	
	@Transactional
	public List<PgOwner> fetchPgOwners() {
		List<PgOwner> pgownerList=pgOwnerRepository.findAll();
		return pgownerList;
		
	}
	@Transactional
	public PgOwner savePgOwner(PgOwner pgowner) {
		
		return pgOwnerRepository.save(pgowner);
		
	}
	@Transactional
	public void updatePgOwner(PgOwner pgowner) {
		pgOwnerRepository.save(pgowner);	
	
	}
	
	@Transactional
	public void deletePgOwner(int pgId) {
		//pgRepository.delete(pg);	
		System.out.println("service method called");
		pgOwnerRepository.deleteById(pgId);
	
	}
	@Transactional 
	  public PgOwner getPgOwner(int id) { 
	  Optional<PgOwner> optional= pgOwnerRepository.findById(id);
	  PgOwner pgowner=optional.get();
	  return pgowner;
	  

}
}
