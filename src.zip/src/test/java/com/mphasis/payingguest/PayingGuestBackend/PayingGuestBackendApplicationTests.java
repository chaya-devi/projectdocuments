package com.mphasis.payingguest.PayingGuestBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayingGuestBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
