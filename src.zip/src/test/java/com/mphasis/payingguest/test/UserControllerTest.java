package com.mphasis.payingguest.test;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mphasis.payingguest.dao.UserRepository;
import com.mphasis.payingguest.dao.UserLoginRepository;
import com.mphasis.payingguest.model.User;
import com.mphasis.payingguest.service.UserService;


@RunWith(SpringRunner.class)
@WebMvcTest
public class UserControllerTest {
	@Autowired
	private MockMvc mvc;

	@MockBean
	private UserService userService;
	
	@MockBean
	private UserRepository userRepository;
	
	@MockBean
	private UserLoginRepository userloginRepository;
	
	private static ObjectMapper mapper = new ObjectMapper();

	@Test
	public void testGetUsers() throws Exception {
		User user = new User();
		user.setId(1);
		user.setusername("sai");
		user.setemail("sri");
		user.setpassword("sai");
		user.setgender("sai");
		user.setphonenumber(0);

		List<User> allUsers = new ArrayList<>();
		allUsers.add(user);

		Mockito.when(userService.fetchUser()).thenReturn(allUsers);

		System.out.println("test method");
		mvc.perform(get("/api/v1/getAllUsers").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$", Matchers.hasSize(1)))
				.andExpect(jsonPath("$[0].username", Matchers.equalTo(user.getusername())));
	}

	@Test
	//@Ignore
	public void testSaveUser() throws Exception {
		User user = new User();
		user.setId(1);
		user.setusername("sai");
	    user.setemail("sri");
		user.setpassword("sri@gmail.com");
		user.setgender("sri@gmail.com");
		user.setphonenumber(998865342);
		Mockito.when(userService.saveUser(ArgumentMatchers.any())).thenReturn(user);
		String json = mapper.writeValueAsString(user);
		mvc.perform(post("/api/v1/saveUser").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
				.content(json).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk());

	}
	
	/**
	 * @throws Exception
	 */

	@Test
	public void testUpdateUser() throws Exception {
		User user = new User();
		user.setId(1);
		user.setusername("Minu");
		user.setemail("sri");
		user.setpassword("sri@gmail.com");
		user.setgender("sri@gmail.com");
		user.setphonenumber(998865342);
		Mockito.when(userService.getUser(ArgumentMatchers.anyInt())).thenReturn(user);
		//Mockito.when(userService.updateUser(user));
		String json = mapper.writeValueAsString(user);
		mvc.perform(put("/api/v1/updateUser/1").contentType(MediaType.APPLICATION_JSON).characterEncoding("utf-8")
				.content(json).accept(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
			.andExpect(jsonPath("$.id", Matchers.equalTo(1)))
				.andExpect(jsonPath("$.username", Matchers.equalTo("Minu")));
	}
	@Test
	public void testGetUserById() throws Exception {
		User user = new User();
		user.setId(1);
		user.setusername("sai");
		user.setemail("sri");
		user.setpassword("sri");
		user.setgender("");
		user.setphonenumber(998865342);
		
		Mockito.when(userService.getUser(ArgumentMatchers.anyInt())).thenReturn(user);
	mvc.perform(get("/api/v1/getUser/{id}",1)
		      .contentType(MediaType.APPLICATION_JSON))
		      .andExpect(status().isOk());
	}
	@Test
    public void testDeleteUser() throws Exception {
		User user = new User();
		user.setId(1);
		user.setusername("sai");
		user.setemail("sri");
	    user.setpassword("sri");
	    user.setgender("sri");
	    user.setphonenumber(998865342);
		Mockito.when(userService.getUser(ArgumentMatchers.anyInt())).thenReturn(user);
        userService.deleteUser(ArgumentMatchers.anyInt());
        MvcResult requestResult = mvc.perform(delete("/api/v1/deleteUser/1"))
        		.andExpect(status().isOk()).andReturn();
        String result = requestResult.getResponse().getContentAsString();
    assertEquals(result, "User deleted successfully");
    }

}


//https://asbnotebook.com/spring-boot-rest-controller-junit-test-example/
