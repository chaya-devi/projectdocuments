package com.mphasis.meetingroom.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.meetingroom.model.Employee;


@Repository
public interface EmployeeRepository extends JpaRepository<Employee ,Integer>  {

//	@Query("SELECT e FROM Employee e WHERE e.status =?1") JPQL
//	Collection<Employee> findAllActiveEmployees();
	
}
