package com.mphasis.meetingroom.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.meetingroom.model.Facilities;

@Repository
public interface FacilitiesRepository extends JpaRepository<Facilities ,Integer>  {
}

