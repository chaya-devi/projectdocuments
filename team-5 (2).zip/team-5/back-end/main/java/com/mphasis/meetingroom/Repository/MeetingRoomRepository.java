package com.mphasis.meetingroom.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.meetingroom.model.MeetingRoom;


@Repository
public interface MeetingRoomRepository extends JpaRepository<MeetingRoom ,Integer>  {

}
