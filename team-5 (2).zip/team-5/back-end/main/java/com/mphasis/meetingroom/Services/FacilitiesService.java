package com.mphasis.meetingroom.Services;


import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.meetingroom.Repository.FacilitiesRepository;
import com.mphasis.meetingroom.model.Facilities;



@Service
public class FacilitiesService {

	@Autowired
	FacilitiesRepository facRepository;
	
	@Transactional
	public List<Facilities> fetchFacilities() {
		List<Facilities> facList=facRepository.findAll();
		return facList;
		
	}
	@Transactional
	public Facilities saveFacilities(Facilities facilities) {
		
		return facRepository.save(facilities);
		
	}
	@Transactional
	public void updateFacilities(Facilities fac) {
		facRepository.save(fac);	
	
	}
	
	@Transactional
	public void deleteFacilities(int roomid) {	
		System.out.println("service method called");
		facRepository.deleteById(roomid);
	
	}
	@Transactional 
	  public Facilities getFacilities(int roomid) { 
	  Optional<Facilities> optional= facRepository.findById(roomid);
	  Facilities fac=optional.get();
	  return fac;
	  

}
}
