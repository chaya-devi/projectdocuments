package com.mphasis.meetingroom.Services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.meetingroom.Repository.EmployeeRepository;
import com.mphasis.meetingroom.Repository.MeetingRoomRepository;
import com.mphasis.meetingroom.model.Employee;
import com.mphasis.meetingroom.model.MeetingRoom;


@Service
public class MeetingRoomService {

	@Autowired
	MeetingRoomRepository meetRepository;
	
	@Transactional
	public List<MeetingRoom> fetchMeetingRooms() {
		List<MeetingRoom> meetList=meetRepository.findAll();
		return meetList;
		
	}
	@Transactional
	public MeetingRoom saveMeetingRoom(MeetingRoom meetingroom) {
		
		return meetRepository.save(meetingroom);
		
	}
	@Transactional
	public void updateMeetingRoom(MeetingRoom meet) {
		meetRepository.save(meet);	
	
	}
	
	@Transactional
	public void deleteMeetingRoom(int empId) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
		meetRepository.deleteById(empId);
	
	}
	@Transactional 
	  public MeetingRoom getMeetingRoom(int empid) { 
	  Optional<MeetingRoom> optional= meetRepository.findById(empid);
	  MeetingRoom meet=optional.get();
	  return meet;
	  

}
}
