package com.mphasis.meetingroom.Services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.meetingroom.Repository.ReservationsRepository;
import com.mphasis.meetingroom.model.Reservations;


@Service
public class ReservationService {

	@Autowired
	ReservationsRepository resRepository;
	
	@Transactional
	public List<Reservations> fetchReservations() {
		List<Reservations> resList=resRepository.findAll();
		return resList;
		
	}
	@Transactional
	public Reservations saveReservations(Reservations reservations) {
		
		return resRepository.save(reservations);
		
	}
	@Transactional
	public void updateReservations(Reservations res) {
		resRepository.save(res);	
	
	}
	
	@Transactional
	public void deleteReservations(int reservationid) {
		//empRepository.delete(emp);	
		System.out.println("service method called");
		resRepository.deleteById(reservationid);
	
	}
	@Transactional 
	  public Reservations getReservations(int reservationid) { 
	  Optional<Reservations> optional= resRepository.findById(reservationid);
	  Reservations res=optional.get();
	  return res;
	  

}
}
