package com.mphasis.meetingroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.meetingroom.Services.ReservationService;
import com.mphasis.meetingroom.exception.ResourceNotFoundException;
import com.mphasis.meetingroom.model.Reservations;

@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class ReservationsController {
	@Autowired
	ReservationService resService;
	@GetMapping("/getAllReservations")
	public List<Reservations> getReservations() {
		List<Reservations> resList = resService.fetchReservations();
		return resList;
	}
	@GetMapping("/getReservations/{reservationid}")
	public ResponseEntity<Reservations> getReservationsById(@PathVariable("reservationid") int reservationid)
			throws ResourceNotFoundException {
		Reservations reservations = resService.getReservations(reservationid);
		return ResponseEntity.ok().body(reservations);
	}
	@PostMapping("/saveReservations")
	public Reservations addReservations(@RequestBody Reservations res) {

		Reservations reservations = resService.saveReservations(res);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return reservations;
	}

	@PutMapping("/updateReservations/{empid}")
	public ResponseEntity<Reservations> updateReservations(@PathVariable("reservstionid") int reservationid,
			@RequestBody Reservations reservationsDetails) throws ResourceNotFoundException {
		Reservations reservations = resService.getReservations(reservationid);

		reservations.setempid(reservationsDetails.getempid());
		reservations.setreservationid(reservationsDetails.getreservationid());
		reservations.setroomstatus(reservationsDetails.getroomstatus());
		reservations.setdateBegin(reservationsDetails.getdateBegin());
		reservations.setdateEnd(reservationsDetails.getdateEnd());
		reservations.setPurpose(reservationsDetails.getPurpose());
		reservations.setmeet_duration(reservationsDetails.getmeet_duration());
		reservations.setcapacity(reservationsDetails.getcapacity());
		final Reservations updatedReservations = resService.saveReservations(reservations);
		return ResponseEntity.ok(updatedReservations);
	}
	@DeleteMapping(value = "/deleteReservations/{reservationid}")
	public ResponseEntity<Object> deleteReservations(@PathVariable("reservationid") int reservationid) {

		resService.deleteReservations(reservationid);
		return new ResponseEntity<>("Reservation deleted successsfully", HttpStatus.OK);
	}
}
