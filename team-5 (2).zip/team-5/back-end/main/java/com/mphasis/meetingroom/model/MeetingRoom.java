package com.mphasis.meetingroom.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="meetingroom")
public class MeetingRoom {
	@Id
	@Column(name="meetroomid")
	private int meetroomid;
	
	@Column(name="meet_reason")
	private String meet_reason;
	
	@Column(name="capacity")
	private Integer capacity;
	
	@Column(name="location")
	private String location;
	
	public MeetingRoom() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MeetingRoom(int meetroomid, String meet_reason, Integer capacity, String location) {
		super();
		this.meetroomid = meetroomid;
		this.meet_reason = meet_reason;
		this.capacity = capacity;
		this.location = location;
	}

	public MeetingRoom( String meet_reason, Integer capacity, String location) {
		super();
		this.meet_reason = meet_reason;
		this.capacity = capacity;
		this.location = location;
	}

	public int getmeetroomid() {
		return meetroomid;
	}

	public void setmeetroomid(int meetroomid) {
		this.meetroomid = meetroomid;
	}

	public String getmeet_reason() {
		return meet_reason;
	}

	public void setmeet_reason(String meet_reason) {
		this.meet_reason= meet_reason;
	}

	public Integer getCapacity() {
		return capacity;
	}

	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	

}
