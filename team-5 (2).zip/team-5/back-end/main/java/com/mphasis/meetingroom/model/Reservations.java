package com.mphasis.meetingroom.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "reservations")
public class Reservations  {

    @Id
    @Column(name = "reservationid")
    private int  reservationid;

    @Column(name = "purpose")
    private String purpose;

    @Column(name = "dateBegin")
    private String dateBegin;

    @Column(name = "dateEnd")
    private String dateEnd;
    @Column(name = "empid")
    private int empid;
    @Column(name = "roomstatus")
    private String roomstatus;

    @Column(name = "meet_duration")
    private String meet_duration;
    @Column(name = "capacity")
    private String capacity;
    public Reservations() {
        super();
        // TODO Auto-generated constructor stub
    }

    public Reservations(String capacity, int reservationid, String meet_duration,String purpose, String dateBegin, String dateEnd,String roomstatus,int empid) {
        super();
        this.reservationid = reservationid;
        this.purpose = purpose;
        this.dateBegin = dateBegin;
        this.dateEnd = dateEnd;
        this.roomstatus = roomstatus;
        this.meet_duration=meet_duration;
        this.empid=empid;
        this.capacity = capacity;
    }

    public String getroomstatus() {
        return roomstatus;
    }

    public void setroomstatus(String roomstatus) {
        this.roomstatus = roomstatus;
    }
    public String getcapacity() {
        return capacity;
    }

    public void setcapacity(String capacity) {
        this.capacity = capacity;
    }

    public int getempid() {
        return empid;
    }

    public void setempid(int empid) {
        this.empid = empid;
    }

    public int getreservationid() {
        return reservationid;
    }

    public void setreservationid(int reservationid) {
        this.reservationid = reservationid;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getdateBegin() {
        return dateBegin;
    }

    public void setdateBegin(String dateBegin) {
        this.dateBegin = dateBegin;
    }

    public String getdateEnd() {
        return dateEnd;
    }

    public void setdateEnd(String dateEnd) {
        this.dateEnd = dateEnd;
    }
    public String getmeet_duration() {
        return meet_duration;
    }

    public void setmeet_duration(String meet_duration) {
        this.meet_duration = meet_duration;
    }


}