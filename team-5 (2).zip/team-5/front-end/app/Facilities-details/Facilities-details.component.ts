import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Facilities } from '../Facilities';
import { FacilitiesService } from '../Facilities.service';

@Component({
  selector: 'app-Facilities-details',
  templateUrl: './Facilities-details.component.html',
  styleUrls: ['./Facilities-details.component.css']
})
export class FacilitiesDetailsComponent implements OnInit {

  id: number=0;
  Facilities: Facilities=new Facilities();

  constructor(private route: ActivatedRoute,private router: Router,private FacilitiesService: FacilitiesService) { }

  ngOnInit() {
    this.Facilities = new Facilities();

    this.id = this.route.snapshot.params['id'];
    
    this.FacilitiesService.getFacilities(this.id)
      .subscribe(data => {
        console.log(data)
        this.Facilities = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['Facilities']);
  }
}




