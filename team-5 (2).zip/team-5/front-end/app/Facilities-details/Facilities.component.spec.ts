import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FacilitiesDetailsComponent } from './Facilities-details.component';


describe('FacilitiesComponent', () => {
  let component: FacilitiesDetailsComponent;
  let fixture: ComponentFixture<FacilitiesDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [  FacilitiesDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FacilitiesDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
