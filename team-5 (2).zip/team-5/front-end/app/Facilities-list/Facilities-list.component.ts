import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Facilities } from '../Facilities';
import { FacilitiesService } from '../Facilities.service';

@Component({
  selector: 'app-Facilities-list',
  templateUrl: './Facilities-list.component.html',
  styleUrls: ['./Facilities-list.component.css']
})

//component-->service-->http request

export class FacilitiesListComponent implements OnInit {
  [x: string]: any;
  Facilities: Observable<Facilities[]>=new Observable;

  constructor(private FacilitiesService: FacilitiesService,private router: Router) {}
  
  ngOnInit(): void {
    this.getFacilities();
  }

  getFacilities()
  {
    this.Facilities=this.FacilitiesService.getfacilities();
  }
  
  deleteFacilities(meetroomid: number) {
    this.FacilitiesService.deleteFacilities(meetroomid)
      .subscribe(
        data => {
          console.log(data);
          this.getFacilities();
        },
        error => console.log(error));
  }

  FacilitiesDetails(id: number){
    this.router.navigate(['detailsfac', id]);
  }
  updateFacilities(meetroomid: number)
  {
    this.router.navigate(['updatefac', meetroomid]);
  }
}
