import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class FacilitiesService {
 
 
  private baseUrl = 'http://localhost:8080/api/v4';

  constructor(private http: HttpClient) { }

  getfacilities(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllFacilities');
  }
  getFacilities(meetroomid: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getFacilities/${meetroomid}`);
  }

  createFacilities(meetingroomid: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveFacilities', meetingroomid);
  }

  updateFacilities(meetroomid: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateFacilities/${meetroomid}`, value);
  }

  deleteFacilities(meetroomid: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteFacilities/${meetroomid}`, { responseType: 'text' });
  }


}
