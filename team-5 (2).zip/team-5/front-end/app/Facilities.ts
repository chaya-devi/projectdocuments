export class Facilities{
    meetroomid:number=0;
    Wifi:string="";
    Projector:string="";
    Coffe:string="";
    Whiteboard:string="";
}