import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Reservations } from '../reservations';
import { ReservationsService } from '../reservations.service';

@Component({
  selector: 'app-Reservations-list',
  templateUrl: './Reservations-list.component.html',
  styleUrls: ['./Reservations-list.component.css']
})

//component-->service-->http request

export class ReservationsListComponent implements OnInit {
  reservations: Observable<Reservations[]>=new Observable;

  constructor(private reservationsService: ReservationsService,private router: Router) {}
  
  ngOnInit(): void {
    this.getReservations();
  }

  getReservations()
  {
    this.reservations=this.reservationsService.getReservation();
  }
  
  deleteReservations(id: number) {
    this.reservationsService.deletereservations(id)
      .subscribe(
        data => {
          console.log(data);
          this.getReservations();
        },
        error => console.log(error));
  }

  ReservationsDetails(id: number){
    this.router.navigate(['details', id]);
  }
  updateReservations(id: number)
  {
    this.router.navigate(['update', id]);
  }
  createReseravtions()
  {
    this.router.navigate(['add' ]);
  }
}
