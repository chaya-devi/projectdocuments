import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { JoinnowComponent } from './joinnow/joinnow.component';
import { CreateReservationsComponent } from './create -Reservations/create-reservations.component';
import { ReservationsDetailsComponent } from './reservations-details/reservations-details.component';
import { ReservationsListComponent } from './reservations-list/reservations-list.component';
import { UpdateReservationsComponent } from './update-reservations/update-reservations.component';
import { CreateMeetingroomComponent } from './create-meetingroom/create-meetingroom.component';
import { MeetingroomDetailsComponent } from './meetingroom-details/meetingroom-details.component';
import { MeetingroomListComponent } from './meetingroom-list/meetingroom-list.component';
import { UpdateMeetingroomComponent } from './update-meetingroom/update-meetingroom.component';
import { FacilitiesListComponent } from './Facilities-list/Facilities-list.component';
import { FacilitiesDetailsComponent } from './Facilities-details/Facilities-details.component';
const routes: Routes = [
  {path:'',component:HomeComponent},
  {path:'joinnow',component:JoinnowComponent},
  { path: '', redirectTo: 'reservations', pathMatch: 'full' },
  { path: 'reservations', component: ReservationsListComponent },
  { path: 'add', component: CreateReservationsComponent },
  { path: 'update/:id', component: UpdateReservationsComponent },
  { path: 'details/:id', component: ReservationsDetailsComponent },
  { path: '', redirectTo: 'meetingroom', pathMatch: 'full' },
  { path: 'meetingroom', component: MeetingroomListComponent },
  { path: 'addmeet', component: CreateMeetingroomComponent },
  { path: 'updatemeet/:meetroomid', component: UpdateMeetingroomComponent },
  { path: 'detailsmeet/:meetroomid', component: MeetingroomDetailsComponent },
  { path: 'Facilities', component: FacilitiesListComponent },
  { path: 'detailsfac/:meetroomid', component: FacilitiesDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
