import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { ReservationsListComponent } from './reservations-list/reservations-list.component';
import { ReservationsService } from './reservations.service';
import { HttpClient } from '@angular/common/http';
import { HttpClientModule } from '@angular/common/http';
import { CreateReservationsComponent } from './create -Reservations/create-reservations.component';
import { UpdateReservationsComponent } from './update-reservations/update-reservations.component';
import { ReservationsDetailsComponent } from './reservations-details/reservations-details.component';
import { CreateMeetingroomComponent } from './create-meetingroom/create-meetingroom.component';
import { UpdateMeetingroomComponent } from './update-meetingroom/update-meetingroom.component';
import { MeetingroomDetailsComponent } from './meetingroom-details/meetingroom-details.component';
import { MeetingroomListComponent } from './meetingroom-list/meetingroom-list.component';
import { MeetingroomService } from './meetingroom.service';
import { HomeComponent } from './home/home.component';
import { JoinnowComponent } from './joinnow/joinnow.component';
import { FacilitiesListComponent } from './Facilities-list/Facilities-list.component';
import { FacilitiesDetailsComponent } from './Facilities-details/Facilities-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    JoinnowComponent,
    ReservationsListComponent,
    CreateReservationsComponent,
    UpdateReservationsComponent,
    ReservationsDetailsComponent,  
    MeetingroomListComponent,
    CreateMeetingroomComponent,
    UpdateMeetingroomComponent,
    MeetingroomDetailsComponent,
    FacilitiesListComponent,
    FacilitiesDetailsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],
  providers: [ReservationsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
