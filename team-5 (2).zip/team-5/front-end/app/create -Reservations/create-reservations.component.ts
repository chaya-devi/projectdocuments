import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Reservations } from '../reservations';
import { ReservationsService } from '../reservations.service';

@Component({
  selector: 'app-create-reservations',
  templateUrl: './create-reservations.component.html',
  styleUrls: ['./create-reservations.component.css']
})
export class CreateReservationsComponent implements OnInit {

  reservations: Reservations = new Reservations();
  submitted = false;

  constructor(private reservationsService: ReservationsService, private router: Router) { }

  ngOnInit() {
  }

  newReservations(): void {
    this.submitted = false;
    this.reservations = new Reservations();
  }

  save() {
    this.reservationsService.createReservations(this.reservations).subscribe(data => {
      console.log(data+" "+this.reservations)
     this.reservations = new Reservations();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/reservations']);
  }


}
