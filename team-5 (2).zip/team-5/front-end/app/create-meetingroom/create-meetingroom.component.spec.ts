import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateMeetingroomComponent } from './create-meetingroom.component';

describe('CreateMeetingroomComponent', () => {
  let component: CreateMeetingroomComponent;
  let fixture: ComponentFixture<CreateMeetingroomComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateMeetingroomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateMeetingroomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
