import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Meetingroom } from '../meeting';
import { MeetingroomService } from '../meetingroom.service';

@Component({
  selector: 'app-create-meetingroom',
  templateUrl: './create-meetingroom.component.html',
  styleUrls: ['./create-meetingroom.component.css']
})
export class CreateMeetingroomComponent implements OnInit {

  meetingroom: Meetingroom = new Meetingroom();
  submitted = false;

  constructor(private meetingroomService: MeetingroomService, private router: Router) { }

  ngOnInit() {
  }

  newMeetingroom(): void {
    this.submitted = false;
    this.meetingroom = new Meetingroom();
  }

  save() {
    this.meetingroomService.createMeetingroom(this.meetingroom).subscribe(data => {
      console.log(data+" "+this.meetingroom)
     this.meetingroom = new Meetingroom();
      this.gotoList();
    },
   error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/meetingroom']);
  }


}
