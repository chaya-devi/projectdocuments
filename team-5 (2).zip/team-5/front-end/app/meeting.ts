export class Meetingroom{
    meetroomid:number=0;
    capacity:number=0;
    location:string="";
    meet_reason:string="";
}