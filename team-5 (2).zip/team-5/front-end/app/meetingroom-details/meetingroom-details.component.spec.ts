import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MeetingroomDetailsComponent } from './meetingroom-details.component';

describe('MeetingroomDetailsComponent', () => {
  let component: MeetingroomDetailsComponent;
  let fixture: ComponentFixture<MeetingroomDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [  MeetingroomDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MeetingroomDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
