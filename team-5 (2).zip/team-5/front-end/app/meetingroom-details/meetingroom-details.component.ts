import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Meetingroom } from '../meeting';
import { MeetingroomService } from '../meetingroom.service';

@Component({
  selector: 'app-meetingroom-details',
  templateUrl: './meetingroom-details.component.html',
  styleUrls: ['./meetingroom-details.component.css']
})
export class MeetingroomDetailsComponent implements OnInit {

  id: number=0;
  meetingroom: Meetingroom=new Meetingroom();

  constructor(private route: ActivatedRoute,private router: Router,private meetingroomService: MeetingroomService) { }

  ngOnInit() {
    this.meetingroom = new Meetingroom();

    this.id = this.route.snapshot.params['id'];
    
    this.meetingroomService.getMeetingroom(this.id)
      .subscribe(data => {
        console.log(data)
        this.meetingroom = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['/meetingroom']);
  }
}




