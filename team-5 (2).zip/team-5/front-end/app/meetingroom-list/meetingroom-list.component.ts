import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Meetingroom } from '../meeting';
import { MeetingroomService } from '../meetingroom.service';

@Component({
  selector: 'app-meetingroom-list',
  templateUrl: './meetingroom-list.component.html',
  styleUrls: ['./meetingroom-list.component.css']
})

//component-->service-->http request

export class MeetingroomListComponent implements OnInit {
  [x: string]: any;
  meetingrooms: Observable<Meetingroom[]>=new Observable;

  constructor(private meetingroomService: MeetingroomService,private router: Router) {}
  
  ngOnInit(): void {
    this.getMeetingRooms();
  }

  getMeetingRooms()
  {
    this.meetingrooms=this.meetingroomService.getmeetingrooms();
  }
  
  deleteMeetingroom(meetroomid: number) {
    this.meetingroomService.deleteMeetingroom(meetroomid)
      .subscribe(
        data => {
          console.log(data);
          this.getMeetingRooms();
        },
        error => console.log(error));
  }

  meetingroomDetails(id: number){
    this.router.navigate(['detailsmeet', id]);
  }
  updateMeetingroom(meetroomid: number)
  
  {
    this.router.navigate(['updatemeet', Meetingroom]);
  }
  createMeetingroom()
  {
    this.router.navigate(['addmeet']);
  }
}
