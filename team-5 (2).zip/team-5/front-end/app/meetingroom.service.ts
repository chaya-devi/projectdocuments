import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MeetingroomService {
 
 
  private baseUrl = 'http://localhost:8080/api/v4';

  constructor(private http: HttpClient) { }

  getmeetingrooms(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+'/getAllMeetingRooms');
  }
  getMeetingroom(meetroomid: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getMeetingRoom/${meetroomid}`);
  }

  createMeetingroom(Meetingroom: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveMeetingRoom', Meetingroom);
  }

  updateMeetingroom(meetroomid: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateMeetingRoom/${meetroomid}`, value);
  }

  deleteMeetingroom(meetroomid: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteMeetingRoom/${meetroomid}`, { responseType: 'text' });
  }


}
