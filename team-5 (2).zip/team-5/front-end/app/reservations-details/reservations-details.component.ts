import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Reservations} from '../reservations';
import { ReservationsService } from '../reservations.service';

@Component({
  selector: 'app-reservations-details',
  templateUrl: './reservations-details.component.html',
  styleUrls: ['./reservations-details.component.css']
})
export class ReservationsDetailsComponent implements OnInit {

  id: number=0;
  reservations: Reservations=new Reservations();
  //Reservations: reservations;

  constructor(private route: ActivatedRoute,private router: Router,private reservationsService: ReservationsService) { }

  ngOnInit() {
    this.reservations = new Reservations();

    this.id = this.route.snapshot.params['id'];
    
    this.reservationsService.getReservations(this.id)
      .subscribe(data => {
        console.log(data)
        this.reservations = data;
      }, error => console.log(error));
      //this.list();
  }

  list(){
    this.router.navigate(['reservations']);
  }
}




