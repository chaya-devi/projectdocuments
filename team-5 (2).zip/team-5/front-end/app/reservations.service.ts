import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient, HttpClientModule}   from '@angular/common/http';
import { Reservations } from './reservations';
@Injectable({
  providedIn: 'root'
})
export class ReservationsService {
  private baseUrl = 'http://localhost:8080/api/v4';
  constructor(private http: HttpClient) { }

  getReservation(): Observable<any> {
    //console.log(this.http.get(`${this.baseUrl}`+'/getAllReservations'));
    return this.http.get(`${this.baseUrl}`+'/getAllReservations');
  }
  getReservations(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/getReservations/${id}`);
  }

  createReservations(reservations: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`+'/saveReservations', reservations);
  }

  updateReservations(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseUrl}/updateReservations/${id}`, value);
  }

  deletereservations(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/deleteReservations/${id}`, { responseType: 'text' });
  }


}
function admin(arg0: string, admin: any): Observable<Object> {
  throw new Error('Function not implemented.');
}

