export class Reservations{
    reservationid:number=0;
    capacity:number=0;
    empid:number=0;
    purpose:string="";
    roomstatus:string="";
    dateBegin:string="";
    dateEnd:string="";
    meet_duration:string="";
}