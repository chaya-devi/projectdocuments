import { Component, OnInit } from '@angular/core';
import { Reservations } from '../reservations';
import { ActivatedRoute, Router } from '@angular/router';
import { ReservationsService } from '../reservations.service';

@Component({
  selector: 'app-update-reservations',
  templateUrl: './update-reservations.component.html',
  styleUrls: ['./update-reservations.component.css']
})
export class UpdateReservationsComponent implements OnInit {

  id: number=0;
  reservations: Reservations=new Reservations();
  //Reservations: reservations;

  constructor(private route: ActivatedRoute,private router: Router,
    private reservationsService: ReservationsService) { }

  ngOnInit() {
    this.reservations= new Reservations();

    this.id = this.route.snapshot.params['id'];
    
    this.reservationsService.getReservations(this.id)
      .subscribe(data => {
        console.log(data)
        this.reservations = data;
      }, error => console.log(error));
  }

  updateReservations() {
    this.reservationsService.updateReservations(this.id, this.reservations)
      .subscribe(data => {
        console.log(data);
        this.reservations = new Reservations();
        this.gotoList();
      }, 
      error => console.log(error));
  }

  onSubmit() {
    this.updateReservations();    
  }

  gotoList() {
    this.router.navigate(['/reservations']);
  }
}
