import { Component, OnInit } from '@angular/core';
import { Meetingroom } from '../meeting';
import { ActivatedRoute, Router } from '@angular/router';
import { MeetingroomService } from '../meetingroom.service';

@Component({
  selector: 'app-update-meetingroom',
  templateUrl: './update-meetingroom.component.html',
  styleUrls: ['./update-meetingroom.component.css']
})
export class UpdateMeetingroomComponent implements OnInit {

  id: number=0;
  meetingroom: Meetingroom=new Meetingroom();

  constructor(private route: ActivatedRoute,private router: Router,
    private meetingroomService: MeetingroomService) { }

  ngOnInit() {
    this.meetingroom = new Meetingroom();

    this.id = this.route.snapshot.params['id'];
    
    this.meetingroomService.getMeetingroom(this.id)
      .subscribe(data => {
        console.log(data)
        this.meetingroom = data;
      }, error => console.log(error));
  }

  updateMeetingroom() {
    this.meetingroomService.updateMeetingroom(this.id, this.meetingroom)
      .subscribe(data => {
        console.log(data);
        this.meetingroom = new Meetingroom();
        this.gotoList();
      }, error => console.log(error));
  }

  onSubmit() {
    this.updateMeetingroom();    
  }

  gotoList() {
    this.router.navigate(['/meetingroom']);
  }
}
