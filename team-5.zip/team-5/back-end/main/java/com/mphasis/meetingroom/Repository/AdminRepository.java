package com.mphasis.meetingroom.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mphasis.meetingroom.model.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin ,Integer>  {

	@Query("SELECT u FROM Admin u WHERE u.username =?1 and u.password=?2")
	public Admin validateAdmin(String username,String password);

}
