package com.mphasis.meetingroom.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.meetingroom.Repository.AdminRepository;
import com.mphasis.meetingroom.model.Admin;



@Service
public class AdminService {
	//@org.springframework.beans.factory.annotation.Autowired(required=true)

	@Autowired 
	AdminRepository admRepository;

	public Admin validateAdmin(Admin adm) {
		Admin u=admRepository.validateAdmin(adm.getUsername(),adm.getPassword());
		
		return u;
	}
	
}
	

		

