package com.mphasis.meetingroom.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.meetingroom.Services.AdminService;
import com.mphasis.meetingroom.model.Admin;


//@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class AdminController {

	@Autowired
	AdminService admService;

		@GetMapping("/loginAdmin")
		public Admin validateUser(@RequestBody Admin adm) 		
		{
			System.out.println("in controller ="+adm.getUsername());
			Admin u = admService.validateAdmin(adm);
		//	if (u==null)
			
			//return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
				
		//	else
			//	return new ResponseEntity<>("Successful login", HttpStatus.OK);
			return u;
		}
	}

		
		
		
		
		
		/*{
			
				Admin u = admService.validateAdmin(adm);
				if (u==null)
				
				return new ResponseEntity<>("Invalid credentials",HttpStatus.NOT_FOUND);
				else
					return new ResponseEntity<>("Successful login", HttpStatus.OK);
			}
		}*/
	