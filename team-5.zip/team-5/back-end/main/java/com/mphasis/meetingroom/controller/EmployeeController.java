package com.mphasis.meetingroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.meetingroom.Services.EmployeeService;
import com.mphasis.meetingroom.exception.ResourceNotFoundException;
import com.mphasis.meetingroom.model.Employee;



//@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class EmployeeController {

	@Autowired
	EmployeeService empService;

//http://localhost:8080/api/v1/getAllEmployees
	@GetMapping("/getAllEmployees")
	public List<Employee> getEmployees() {
		List<Employee> empList = empService.fetchEmployees();
		return empList;

	}

	// http://localhost:8080/api/v1/getEmployee/1
	@GetMapping("/getEmployee/{empid}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("empid") int empid)
			throws ResourceNotFoundException {
		Employee employee = empService.getEmployee(empid);
		return ResponseEntity.ok().body(employee);
	}

	// http://localhost:8080/api/v1/saveEmployee
	@PostMapping("/saveEmployee")
	public Employee addEmployee(@RequestBody Employee emp) {

		Employee employee = empService.saveEmployee(emp);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return employee;
	}

	// http://localhost:8080/api/v1/updateEmployee/2
	@PutMapping("/updateEmployee/{empid}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable("empid") int employeeId,
			@RequestBody Employee employeeDetails) throws ResourceNotFoundException {
		Employee employee = empService.getEmployee(employeeId);

		employee.setempid(employeeDetails.getempid());
		employee.setempname(employeeDetails.getempname());
		employee.setemailId(employeeDetails.getemailId());
		final Employee updatedEmployee = empService.saveEmployee(employee);
		return ResponseEntity.ok(updatedEmployee);
	}

//http://localhost:8080/api/v1/deleteEmployee/1
	@DeleteMapping(value = "/deleteEmployee/{empid}")
	public ResponseEntity<Object> deleteEmployee(@PathVariable("empid") int empid) {

		empService.deleteEmployee(empid);
		return new ResponseEntity<>("Employee deleted successsfully", HttpStatus.OK);
	}
	/*
	 * @DeleteMapping("/deleteEmployee/{id}") public Map<String, Boolean>
	 * deleteEmployee(@PathVariable("id") int employeeId) throws
	 * ResourceNotFoundException { // Employee employee =
	 * empService.getEmployee(employeeId);
	 * 
	 * System.out.println("delete method called");
	 * empService.deleteEmployee(employeeId); Map<String, Boolean> response = new
	 * HashMap<>(); response.put("deleted", Boolean.TRUE); return response; }
	 */

}
