package com.mphasis.meetingroom.controller;

import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.meetingroom.Services.FacilitiesService;
import com.mphasis.meetingroom.exception.ResourceNotFoundException;
import com.mphasis.meetingroom.model.Facilities;




@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class FacilitiesController {

	@Autowired
	FacilitiesService facService;
	@GetMapping("/getAllFacilities")
	public List<Facilities> getFacilities() {
		List<Facilities> facList = facService.fetchFacilities();
		return  facList;
	}
	@GetMapping("/getFacilities/{meetroomid}")
	public ResponseEntity<Facilities> getFacilitiesByroomid(@PathVariable("meetroomid") int meetroomid)
			throws ResourceNotFoundException {
		Facilities facilities = facService.getFacilities(meetroomid);
		return ResponseEntity.ok().body(facilities);
	}
	@PostMapping("/saveFacilities")
	public Facilities addFacilities(@RequestBody Facilities fac) {

		Facilities facilities = facService.saveFacilities(fac);

		return facilities;
	}

	@PutMapping("/updateFacilities/{meetroomid}")
	public ResponseEntity<Facilities> updateFacilities(@PathVariable("meetroomid") int meetroomid,
			@RequestBody Facilities facilitiesDetails) throws ResourceNotFoundException {
		Facilities facilities = facService.getFacilities(meetroomid);

		facilities.setwifi(facilitiesDetails.getwifi());
		facilities.setwhiteboard(facilitiesDetails.getwhiteboard());
		facilities.setcoffe(facilitiesDetails.getcoffe());
		facilities.setprojector(facilitiesDetails.getprojector());
		facilities.setmeetroomid(facilitiesDetails.getmeetroomid());
		final Facilities updatedFacilities = facService.saveFacilities(facilities);
		return ResponseEntity.ok(updatedFacilities);
	}

	@DeleteMapping(value = "/deleteFacilities/{meetroomid}")
	public ResponseEntity<Object> deleteFacilities(@PathVariable("meetroomid") int meetroomid) {

		facService.deleteFacilities(meetroomid);
		return new ResponseEntity<>("Facilities deleted successsfully", HttpStatus.OK);
	}
	
}
