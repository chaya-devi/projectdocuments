package com.mphasis.meetingroom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.meetingroom.Services.MeetingRoomService;
import com.mphasis.meetingroom.exception.ResourceNotFoundException;
import com.mphasis.meetingroom.model.MeetingRoom;



@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api/v4")
@RestController
public class MeetingRoomController {

	@Autowired
	MeetingRoomService meetService;

//http://localhost:8080/api/v1/getAllEmployees
	@GetMapping("/getAllMeetingRooms")
	public List<MeetingRoom> getMeetingRooms() {
		List<MeetingRoom> meetList = meetService.fetchMeetingRooms();
		return meetList;

	}

	// http://localhost:8080/api/v1/getEmployee/1
	@GetMapping("/getMeetingRoom/{meetroomid}")
	public ResponseEntity<MeetingRoom> getMeetingRoomById(@PathVariable("meetroomid") int meetroomid)
			throws ResourceNotFoundException {
		MeetingRoom meetingroom = meetService.getMeetingRoom(meetroomid);
		return ResponseEntity.ok().body(meetingroom);
	}

	// http://localhost:8080/api/v1/saveEmployee
	@PostMapping("/saveMeetingRoom")
	public MeetingRoom addMeetingRoom(@RequestBody MeetingRoom meet) {

		MeetingRoom meetingroom = meetService.saveMeetingRoom(meet);

		// return new ResponseEntity<>("Employee added successsfully", HttpStatus.OK);
		return meetingroom;
	}

	// http://localhost:8080/api/v1/updateEmployee/2
	@PutMapping("/updateMeetingRoom/{meetroomid}")
	public ResponseEntity<MeetingRoom> updateMeetingRoom(@PathVariable("meetroomid") int meetroomid,
			@RequestBody MeetingRoom meetingroomDetails) throws ResourceNotFoundException {
		MeetingRoom meetingroom = meetService.getMeetingRoom(meetroomid);

		meetingroom.setmeetroomid(meetingroomDetails.getmeetroomid());
		meetingroom.setCapacity(meetingroomDetails.getCapacity());
		meetingroom.setLocation(meetingroomDetails.getLocation());
		meetingroom.setmeet_reason(meetingroomDetails.getmeet_reason());
		final MeetingRoom updatedMeetingRoom = meetService.saveMeetingRoom( meetingroom);
		return ResponseEntity.ok(updatedMeetingRoom);
	}

//http://localhost:8080/api/v1/deleteEmployee/1
	@DeleteMapping(value = "/deleteMeetingRoom/{meetroomid}")
	public ResponseEntity<Object> deleteMeetingRoom(@PathVariable("meetroomid") int meetroomid) {

		meetService.deleteMeetingRoom(meetroomid);
		return new ResponseEntity<>(" MeetingRoom deleted successsfully", HttpStatus.OK);
	}
	
}
