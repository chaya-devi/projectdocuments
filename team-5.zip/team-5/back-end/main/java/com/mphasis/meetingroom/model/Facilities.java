package com.mphasis.meetingroom.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="facilities")
public class Facilities {
	@Id
	@Column(name="meetroomid")
	private int meetroomid;
	@Column(name="wifi")
	private String  wifi;
	@Column(name="whiteboard")
	private String  whiteboard;
	@Column(name="projector")
	private String  projector;
	@Column(name="coffe")
	private String  coffe;
	public  Facilities (String wifi, String coffe,String projector,String whiteboard,int meetroomid ) {
        super();
        this.coffe = coffe;
        this.projector = projector;
        this.meetroomid=meetroomid;
        this.whiteboard=whiteboard;
        this.wifi=wifi;
    }
	public Facilities() {
		// TODO Auto-generated constructor stub
	}

	
	
	public int getmeetroomid() {
		return meetroomid;
	}
	public void setmeetroomid(int meetroomid) {
		this.meetroomid = meetroomid;
	}
	public String getcoffe() {
		return coffe;
	}
	public void setcoffe(String coffe) {
		this.coffe = coffe;
	}
	public String getwhiteboard() {
		return whiteboard;
	}
	public void setwhiteboard(String whiteboard) {
		this.whiteboard = whiteboard;
	}
	

public String getprojector() {
	return projector;
}
public void setprojector(String projector) {
	this.projector = projector;
}
public String getwifi() {
	return wifi;
}
public void   setwifi(String wifi) {
	this.wifi = wifi;
}
}
